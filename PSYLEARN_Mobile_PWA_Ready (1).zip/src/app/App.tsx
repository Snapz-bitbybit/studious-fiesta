import { useState } from 'react';
import { LandingScreen } from './components/LandingScreen';
import { Home } from './components/Home';
import { YearSelection } from './components/YearSelection';
import { ModeSelection } from './components/ModeSelection';
import { Quiz } from './components/Quiz';
import { Results } from './components/Results';
import { MemoryGame } from './components/MemoryGame';
import { Notes } from './components/Notes';
import { Journal } from './components/Journal';
import { VarkAssessment } from './components/VarkAssessment';

export type Subject = {
  id: string;
  name: string;
  icon: string;
  color: string;
  topics: Topic[];
};

export type Topic = {
  id: string;
  name: string;
  questions: Question[];
  completed: boolean;
  score?: number;
};

export type Question = {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
};

export type Screen = 'landing' | 'home' | 'yearSelection' | 'modeSelection' | 'quiz' | 'results' | 'memoryGame' | 'notes' | 'journal' | 'vark';

export type QuizMode = 'understanding' | 'memorizing' | 'challenge';

export type Year = {
  id: string;
  name: string;
  subjects: Subject[];
};

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');
  const [selectedYear, setSelectedYear] = useState<Year | null>(null);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);
  const [selectedMode, setSelectedMode] = useState<QuizMode>('understanding');
  const [quizResults, setQuizResults] = useState<{ correct: number; total: number; answers: boolean[] }>({
    correct: 0,
    total: 0,
    answers: []
  });

  const handleEnterApp = () => {
    setCurrentScreen('home');
  };

  const handleYearSelect = (year: Year) => {
    setSelectedYear(year);
    setCurrentScreen('yearSelection');
  };

  const handleTopicSelect = (subject: Subject, topic: Topic) => {
    setSelectedSubject(subject);
    setSelectedTopic(topic);
    setCurrentScreen('modeSelection');
  };

  const handleModeSelect = (mode: QuizMode) => {
    setSelectedMode(mode);
    setCurrentScreen('quiz');
  };

  const handleQuizComplete = (correct: number, total: number, answers: boolean[]) => {
    setQuizResults({ correct, total, answers });
    setCurrentScreen('results');
  };

  const handleBackToHome = () => {
    setCurrentScreen('home');
    setSelectedYear(null);
    setSelectedSubject(null);
    setSelectedTopic(null);
  };

  const handleBackToYear = () => {
    setCurrentScreen('yearSelection');
    setSelectedSubject(null);
    setSelectedTopic(null);
  };

  const handleBackToModes = () => {
    setCurrentScreen('modeSelection');
  };

  const handleRetryQuiz = () => {
    setCurrentScreen('quiz');
  };

  const handlePlayMemoryGame = () => {
    setCurrentScreen('memoryGame');
  };

  const handleOpenNotes = () => {
    setCurrentScreen('notes');
  };

  const handleOpenJournal = () => {
    setCurrentScreen('journal');
  };

  const handleOpenVark = () => {
    setCurrentScreen('vark');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {currentScreen === 'landing' && (
        <LandingScreen onEnter={handleEnterApp} />
      )}
      {currentScreen === 'home' && (
        <Home 
          onYearSelect={handleYearSelect}
          onPlayMemoryGame={handlePlayMemoryGame}
          onOpenNotes={handleOpenNotes}
          onOpenJournal={handleOpenJournal}
          onOpenVark={handleOpenVark}
        />
      )}
      {currentScreen === 'yearSelection' && selectedYear && (
        <YearSelection
          year={selectedYear}
          onStartQuiz={handleTopicSelect}
          onBack={handleBackToHome}
        />
      )}
      {currentScreen === 'modeSelection' && selectedSubject && selectedTopic && (
        <ModeSelection
          subject={selectedSubject}
          topic={selectedTopic}
          onModeSelect={handleModeSelect}
          onBack={handleBackToYear}
        />
      )}
      {currentScreen === 'quiz' && selectedTopic && (
        <Quiz
          topic={selectedTopic}
          subjectName={selectedSubject?.name || ''}
          subjectColor={selectedSubject?.color || 'purple'}
          mode={selectedMode}
          onComplete={handleQuizComplete}
          onBack={handleBackToModes}
        />
      )}
      {currentScreen === 'results' && selectedTopic && (
        <Results
          results={quizResults}
          topicName={selectedTopic.name}
          subjectName={selectedSubject?.name || ''}
          onBackToHome={handleBackToHome}
          onRetry={handleRetryQuiz}
        />
      )}
      {currentScreen === 'memoryGame' && (
        <MemoryGame onBack={handleBackToHome} />
      )}
      {currentScreen === 'notes' && (
        <Notes onBack={handleBackToHome} />
      )}
      {currentScreen === 'journal' && (
        <Journal onBack={handleBackToHome} />
      )}
      {currentScreen === 'vark' && (
        <VarkAssessment onBack={handleBackToHome} />
      )}
    </div>
  );
}

export default App;