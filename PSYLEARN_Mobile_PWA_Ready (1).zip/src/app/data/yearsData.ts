import { Year } from '../App';

export const yearsData: Year[] = [
  {
    id: 'year1',
    name: 'Year 1',
    subjects: [
      {
        id: 'intro-cog-sci',
        name: 'Introduction to Cognitive Sciences',
        icon: 'brain',
        color: 'purple',
        topics: [
          {
            id: 'foundations-cog-sci',
            name: 'Foundations of Cognitive Science',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is cognitive science?',
                options: ['Study of the brain only', 'Interdisciplinary study of mind and intelligence', 'Study of behavior', 'Study of emotions'],
                correctAnswer: 1,
                explanation: 'Cognitive science is an interdisciplinary field that studies mind and intelligence, combining psychology, neuroscience, AI, linguistics, and philosophy.'
              },
              {
                id: '2',
                question: 'Which disciplines contribute to cognitive science?',
                options: ['Psychology only', 'Psychology, neuroscience, AI, linguistics, philosophy', 'Biology and chemistry', 'Mathematics only'],
                correctAnswer: 1,
                explanation: 'Cognitive science integrates multiple disciplines including psychology, neuroscience, artificial intelligence, linguistics, philosophy, and anthropology.'
              },
              {
                id: '3',
                question: 'What is the computational theory of mind?',
                options: ['Minds are computers', 'Mind processes information like a computer', 'Computers have minds', 'Mind controls computers'],
                correctAnswer: 1,
                explanation: 'The computational theory suggests the mind processes information through representations and computations, similar to how computers operate.'
              },
              {
                id: '4',
                question: 'What is embodied cognition?',
                options: ['Mind is separate from body', 'Body influences cognitive processes', 'Only brain matters', 'Physical fitness'],
                correctAnswer: 1,
                explanation: 'Embodied cognition proposes that cognitive processes are deeply rooted in the body\'s interactions with the world.'
              },
              {
                id: '5',
                question: 'What is a mental representation?',
                options: ['A picture in the mind', 'Internal coding of information', 'Memory only', 'Imagination'],
                correctAnswer: 1,
                explanation: 'Mental representations are internal symbols or codes that stand for external objects, concepts, or events.'
              },
              {
                id: '6',
                question: 'Which method is used in cognitive neuroscience?',
                options: ['Only surveys', 'fMRI and EEG brain imaging', 'Observation only', 'Interviews only'],
                correctAnswer: 1,
                explanation: 'Cognitive neuroscience uses brain imaging techniques like fMRI and EEG to study neural basis of cognition.'
              },
              {
                id: '7',
                question: 'What is the symbol grounding problem?',
                options: ['How symbols get meaning', 'How to create symbols', 'How to remember symbols', 'How to write symbols'],
                correctAnswer: 0,
                explanation: 'The symbol grounding problem asks how abstract symbols in the mind connect to real-world referents and acquire meaning.'
              },
              {
                id: '8',
                question: 'What is modularity of mind?',
                options: ['Mind is one unit', 'Mind consists of specialized modules', 'Mind is simple', 'Mind is complex'],
                correctAnswer: 1,
                explanation: 'Modularity theory suggests the mind is composed of specialized, innate modules for different cognitive tasks.'
              },
              {
                id: '9',
                question: 'What is parallel distributed processing?',
                options: ['Linear processing', 'Multiple processes occurring simultaneously', 'One at a time', 'Sequential steps'],
                correctAnswer: 1,
                explanation: 'PDP models propose that cognitive processes occur through parallel activation of interconnected units, like neural networks.'
              },
              {
                id: '10',
                question: 'What is the frame problem in AI?',
                options: ['Picture frames', 'Determining relevant information in changing contexts', 'Computer frames', 'Time frames'],
                correctAnswer: 1,
                explanation: 'The frame problem is the challenge of representing the effects of actions and determining what changes and what stays the same.'
              }
            ]
          }
        ]
      },
      {
        id: 'cognitive-psych-y1',
        name: 'Cognitive Psychology',
        icon: 'brain',
        color: 'indigo',
        topics: [
          {
            id: 'memory-systems',
            name: 'Memory Systems',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is the capacity of short-term memory according to Miller?',
                options: ['5 ± 2 items', '7 ± 2 items', '9 ± 2 items', 'Unlimited'],
                correctAnswer: 1,
                explanation: 'George Miller found that short-term memory can hold approximately 7 ± 2 items, known as the "magical number seven."'
              },
              {
                id: '2',
                question: 'What are the components of Baddeley\'s working memory model?',
                options: ['Only phonological loop', 'Phonological loop, visuospatial sketchpad, central executive, episodic buffer', 'Just memory', 'Short and long term'],
                correctAnswer: 1,
                explanation: 'Baddeley\'s model includes the phonological loop, visuospatial sketchpad, central executive, and episodic buffer.'
              },
              {
                id: '3',
                question: 'What is semantic memory?',
                options: ['Personal experiences', 'General knowledge and facts', 'Motor skills', 'Temporary storage'],
                correctAnswer: 1,
                explanation: 'Semantic memory stores general knowledge, facts, concepts, and meanings independent of personal experience.'
              },
              {
                id: '4',
                question: 'What is episodic memory?',
                options: ['Facts only', 'Personal experiences in time and place', 'Skills', 'General knowledge'],
                correctAnswer: 1,
                explanation: 'Episodic memory stores personal experiences and specific events that occurred at a particular time and place.'
              },
              {
                id: '5',
                question: 'What is the levels of processing theory?',
                options: ['All processing is equal', 'Deeper processing leads to better retention', 'Surface processing is better', 'No difference'],
                correctAnswer: 1,
                explanation: 'Craik and Lockhart proposed that deeper, semantic processing leads to better memory retention than shallow processing.'
              },
              {
                id: '6',
                question: 'What is chunking?',
                options: ['Breaking information', 'Grouping information into meaningful units', 'Forgetting', 'Repeating'],
                correctAnswer: 1,
                explanation: 'Chunking groups individual pieces of information into larger, meaningful units to overcome memory capacity limits.'
              },
              {
                id: '7',
                question: 'What is the primacy effect?',
                options: ['Better recall of last items', 'Better recall of first items', 'Equal recall', 'Random recall'],
                correctAnswer: 1,
                explanation: 'The primacy effect is the tendency to better remember items presented at the beginning of a list.'
              },
              {
                id: '8',
                question: 'What is the recency effect?',
                options: ['Better recall of first items', 'Better recall of last items', 'Poor recall overall', 'No pattern'],
                correctAnswer: 1,
                explanation: 'The recency effect is the tendency to best remember the most recently presented items in a list.'
              },
              {
                id: '9',
                question: 'What is procedural memory?',
                options: ['Facts and events', 'How to perform skills and tasks', 'Short-term storage', 'Sensory information'],
                correctAnswer: 1,
                explanation: 'Procedural memory stores information about how to perform skills and tasks, often unconsciously.'
              },
              {
                id: '10',
                question: 'What is encoding specificity?',
                options: ['All encoding is the same', 'Retrieval is better when context matches encoding', 'Encoding doesn\'t matter', 'Random retrieval'],
                correctAnswer: 1,
                explanation: 'Encoding specificity principle states that memory is improved when retrieval conditions match encoding conditions.'
              }
            ]
          }
        ]
      },
      {
        id: 'intro-psychology',
        name: 'Introduction to Psychology',
        icon: 'lightbulb',
        color: 'blue',
        topics: [
          {
            id: 'foundations',
            name: 'Foundations of Psychology',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'Who is considered the father of psychology?',
                options: ['Sigmund Freud', 'Wilhelm Wundt', 'B.F. Skinner', 'Carl Jung'],
                correctAnswer: 1,
                explanation: 'Wilhelm Wundt established the first psychology laboratory in 1879 in Leipzig, Germany, marking psychology as a formal discipline.'
              },
              {
                id: '2',
                question: 'What is the main focus of behaviorism?',
                options: ['Unconscious mind', 'Observable behavior', 'Mental processes', 'Emotions'],
                correctAnswer: 1,
                explanation: 'Behaviorism focuses on observable behavior rather than internal mental states, emphasizing environmental factors.'
              },
              {
                id: '3',
                question: 'What does the psychodynamic approach emphasize?',
                options: ['Free will', 'Unconscious processes', 'Observable behavior', 'Cognitive processes'],
                correctAnswer: 1,
                explanation: 'The psychodynamic approach emphasizes unconscious processes and early childhood experiences in shaping behavior.'
              },
              {
                id: '4',
                question: 'Which approach focuses on personal growth and self-actualization?',
                options: ['Behaviorism', 'Cognitive', 'Humanistic', 'Biological'],
                correctAnswer: 2,
                explanation: 'The humanistic approach emphasizes personal growth, free will, and self-actualization.'
              },
              {
                id: '5',
                question: 'What is introspection?',
                options: ['Observing others', 'Examining one\'s own thoughts', 'Brain scanning', 'Testing'],
                correctAnswer: 1,
                explanation: 'Introspection is the examination of one\'s own conscious thoughts and feelings.'
              },
              {
                id: '6',
                question: 'Who proposed operant conditioning?',
                options: ['Pavlov', 'B.F. Skinner', 'Watson', 'Bandura'],
                correctAnswer: 1,
                explanation: 'B.F. Skinner developed operant conditioning theory, explaining learning through consequences.'
              },
              {
                id: '7',
                question: 'What is the nature vs. nurture debate?',
                options: ['Brain vs. mind', 'Genes vs. environment', 'Conscious vs. unconscious', 'Thinking vs. feeling'],
                correctAnswer: 1,
                explanation: 'The nature vs. nurture debate concerns genetic inheritance versus environmental factors in development.'
              },
              {
                id: '8',
                question: 'Which perspective examines evolution\'s influence on behavior?',
                options: ['Cognitive', 'Evolutionary', 'Humanistic', 'Psychodynamic'],
                correctAnswer: 1,
                explanation: 'The evolutionary perspective examines how natural selection shaped psychological traits.'
              },
              {
                id: '9',
                question: 'What is empiricism?',
                options: ['Using theory only', 'Knowledge from experience and observation', 'Intuition', 'Tradition'],
                correctAnswer: 1,
                explanation: 'Empiricism holds that knowledge comes from sensory experience and observation.'
              },
              {
                id: '10',
                question: 'Who developed the hierarchy of needs?',
                options: ['Rogers', 'Abraham Maslow', 'Freud', 'Erikson'],
                correctAnswer: 1,
                explanation: 'Abraham Maslow developed the hierarchy of needs from basic physiological needs to self-actualization.'
              }
            ]
          }
        ]
      },
      {
        id: 'basic-helping',
        name: 'Basic Helping Skills',
        icon: 'heart',
        color: 'pink',
        topics: [
          {
            id: 'helping-skills',
            name: 'Core Helping Skills',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is active listening?',
                options: ['Talking a lot', 'Fully concentrating and responding appropriately', 'Interrupting', 'Giving advice'],
                correctAnswer: 1,
                explanation: 'Active listening involves full attention, understanding, and appropriate responses without judgment.'
              },
              {
                id: '2',
                question: 'What is empathy?',
                options: ['Feeling sorry', 'Understanding another\'s perspective', 'Sympathy', 'Agreement'],
                correctAnswer: 1,
                explanation: 'Empathy is understanding and sharing another person\'s emotional experience.'
              },
              {
                id: '3',
                question: 'What is genuineness in helping?',
                options: ['Being fake', 'Being authentic and honest', 'Following scripts', 'Professional distance'],
                correctAnswer: 1,
                explanation: 'Genuineness means being authentic, congruent, and honest in the helping relationship.'
              },
              {
                id: '4',
                question: 'What are open-ended questions?',
                options: ['Yes/no questions', 'Questions requiring detailed responses', 'Multiple choice', 'Short answer'],
                correctAnswer: 1,
                explanation: 'Open-ended questions encourage elaboration and exploration rather than simple yes/no answers.'
              },
              {
                id: '5',
                question: 'What is reflection?',
                options: ['Thinking quietly', 'Mirroring back client\'s feelings', 'Self-examination', 'Analysis'],
                correctAnswer: 1,
                explanation: 'Reflection involves paraphrasing and mirroring back the client\'s emotions and content.'
              },
              {
                id: '6',
                question: 'What is unconditional positive regard?',
                options: ['Judging clients', 'Accepting without conditions', 'Giving rewards', 'Being strict'],
                correctAnswer: 1,
                explanation: 'Unconditional positive regard means accepting and supporting clients without judgment or conditions.'
              },
              {
                id: '7',
                question: 'What is summarization?',
                options: ['Brief notes', 'Condensing key themes discussed', 'Ending conversation', 'Starting over'],
                correctAnswer: 1,
                explanation: 'Summarization condenses and highlights key themes and points from the conversation.'
              },
              {
                id: '8',
                question: 'What is attending behavior?',
                options: ['Ignoring client', 'Physical and psychological presence', 'Arriving on time', 'Taking notes'],
                correctAnswer: 1,
                explanation: 'Attending behavior includes eye contact, body language, and psychological presence showing engagement.'
              },
              {
                id: '9',
                question: 'What is clarification?',
                options: ['Confusion', 'Seeking to understand better', 'Explaining to client', 'Correction'],
                correctAnswer: 1,
                explanation: 'Clarification seeks to better understand what the client means through questions and paraphrasing.'
              },
              {
                id: '10',
                question: 'What is rapport?',
                options: ['Conflict', 'Trusting relationship', 'Distance', 'Formality'],
                correctAnswer: 1,
                explanation: 'Rapport is a harmonious, trusting relationship between helper and client.'
              }
            ]
          }
        ]
      },
      {
        id: 'developmental-y1',
        name: 'Developmental Psychology',
        icon: 'baby',
        color: 'green',
        topics: [
          {
            id: 'piaget',
            name: "Piaget's Cognitive Development",
            completed: false,
            questions: [
              {
                id: '1',
                question: 'At what stage does object permanence develop?',
                options: ['Preoperational', 'Sensorimotor', 'Concrete operational', 'Formal operational'],
                correctAnswer: 1,
                explanation: 'Object permanence develops during the sensorimotor stage (0-2 years).'
              },
              {
                id: '2',
                question: 'What characterizes the preoperational stage?',
                options: ['Abstract thinking', 'Egocentric thinking', 'Conservation', 'Logic'],
                correctAnswer: 1,
                explanation: 'The preoperational stage (2-7 years) is characterized by egocentric thinking and symbolic play.'
              },
              {
                id: '3',
                question: 'When is conservation mastered?',
                options: ['Sensorimotor', 'Preoperational', 'Concrete operational', 'Formal operational'],
                correctAnswer: 2,
                explanation: 'Conservation is mastered during the concrete operational stage (7-11 years).'
              },
              {
                id: '4',
                question: 'What is accommodation?',
                options: ['Fitting into existing schemas', 'Modifying schemas for new info', 'Ignoring information', 'Memorizing'],
                correctAnswer: 1,
                explanation: 'Accommodation is modifying existing schemas or creating new ones to fit new information.'
              },
              {
                id: '5',
                question: 'When does abstract thinking emerge?',
                options: ['Sensorimotor', 'Preoperational', 'Concrete operational', 'Formal operational'],
                correctAnswer: 3,
                explanation: 'Abstract and hypothetical thinking emerges in the formal operational stage (11+ years).'
              },
              {
                id: '6',
                question: 'What is assimilation?',
                options: ['Changing schemas', 'Fitting new info into existing schemas', 'Creating schemas', 'Deleting schemas'],
                correctAnswer: 1,
                explanation: 'Assimilation is interpreting new experiences using existing mental schemas.'
              },
              {
                id: '7',
                question: 'What is egocentrism?',
                options: ['Selfishness', 'Inability to see others\' perspectives', 'Self-awareness', 'Independence'],
                correctAnswer: 1,
                explanation: 'Egocentrism is the inability to differentiate between one\'s own perspective and others\'.'
              },
              {
                id: '8',
                question: 'What is a schema?',
                options: ['A memory', 'A mental framework', 'A behavior', 'A stage'],
                correctAnswer: 1,
                explanation: 'A schema is a mental framework that helps organize and interpret information.'
              },
              {
                id: '9',
                question: 'What does the three mountains task test?',
                options: ['Memory', 'Egocentrism', 'Conservation', 'Abstract thinking'],
                correctAnswer: 1,
                explanation: 'The three mountains task tests whether children can take another person\'s perspective.'
              },
              {
                id: '10',
                question: 'What is centration?',
                options: ['Focusing on multiple aspects', 'Focusing on one aspect only', 'Balanced thinking', 'Abstract reasoning'],
                correctAnswer: 1,
                explanation: 'Centration is focusing on only one aspect of a situation while ignoring others.'
              }
            ]
          }
        ]
      },
      {
        id: 'cognitive-neuro',
        name: 'Cognitive Neuroscience',
        icon: 'brain',
        color: 'orange',
        topics: [
          {
            id: 'brain-cognition',
            name: 'Brain and Cognition',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'Which brain structure is crucial for memory formation?',
                options: ['Amygdala', 'Hippocampus', 'Cerebellum', 'Thalamus'],
                correctAnswer: 1,
                explanation: 'The hippocampus is essential for forming new declarative memories and spatial navigation.'
              },
              {
                id: '2',
                question: 'What is the primary function of the amygdala?',
                options: ['Language', 'Motor control', 'Emotional processing, especially fear', 'Vision'],
                correctAnswer: 2,
                explanation: 'The amygdala processes emotions, particularly fear and threat detection.'
              },
              {
                id: '3',
                question: 'Which neurotransmitter is associated with reward?',
                options: ['Serotonin', 'GABA', 'Dopamine', 'Glutamate'],
                correctAnswer: 2,
                explanation: 'Dopamine is associated with reward, motivation, and pleasure.'
              },
              {
                id: '4',
                question: 'What is neuroplasticity?',
                options: ['Brain rigidity', 'Brain\'s ability to change and adapt', 'Brain damage', 'Fixed pathways'],
                correctAnswer: 1,
                explanation: 'Neuroplasticity is the brain\'s ability to reorganize and form new neural connections.'
              },
              {
                id: '5',
                question: 'Which hemisphere is typically dominant for language?',
                options: ['Right', 'Left', 'Both equally', 'Neither'],
                correctAnswer: 1,
                explanation: 'For most people (~95% right-handed), the left hemisphere is dominant for language.'
              },
              {
                id: '6',
                question: 'What is fMRI used for?',
                options: ['Measuring electrical activity', 'Measuring brain blood flow and activity', 'Surgery', 'Therapy'],
                correctAnswer: 1,
                explanation: 'fMRI (functional Magnetic Resonance Imaging) measures brain activity by detecting blood flow changes.'
              },
              {
                id: '7',
                question: 'What is the corpus callosum?',
                options: ['A brain region', 'Connection between brain hemispheres', 'A neurotransmitter', 'A brain disorder'],
                correctAnswer: 1,
                explanation: 'The corpus callosum is the bundle of nerve fibers connecting the left and right brain hemispheres.'
              },
              {
                id: '8',
                question: 'Which lobe is responsible for vision?',
                options: ['Frontal', 'Parietal', 'Temporal', 'Occipital'],
                correctAnswer: 3,
                explanation: 'The occipital lobe, located at the back of the brain, processes visual information.'
              },
              {
                id: '9',
                question: 'What is the prefrontal cortex responsible for?',
                options: ['Vision', 'Hearing', 'Executive functions and decision-making', 'Balance'],
                correctAnswer: 2,
                explanation: 'The prefrontal cortex handles executive functions including planning, decision-making, and impulse control.'
              },
              {
                id: '10',
                question: 'What is Broca\'s area responsible for?',
                options: ['Understanding language', 'Producing speech', 'Memory', 'Emotion'],
                correctAnswer: 1,
                explanation: 'Broca\'s area in the left frontal lobe is crucial for speech production.'
              }
            ]
          }
        ]
      },
      {
        id: 'social-psych-y1',
        name: 'Social Psychology',
        icon: 'users',
        color: 'red',
        topics: [
          {
            id: 'social-influence',
            name: 'Social Influence',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'Who conducted the line conformity experiment?',
                options: ['Milgram', 'Asch', 'Zimbardo', 'Festinger'],
                correctAnswer: 1,
                explanation: 'Solomon Asch conducted experiments showing people conform to obviously incorrect group judgments.'
              },
              {
                id: '2',
                question: 'What did Milgram\'s obedience studies demonstrate?',
                options: ['People resist authority', 'People obey authority even when harmful', 'Groups decide better', 'Aggression is natural'],
                correctAnswer: 1,
                explanation: 'Milgram showed people obey authority figures even when instructed to harm others.'
              },
              {
                id: '3',
                question: 'What is normative social influence?',
                options: ['Conforming to be right', 'Conforming to be liked', 'Resisting pressure', 'Leadership'],
                correctAnswer: 1,
                explanation: 'Normative social influence is conforming to gain approval and avoid rejection.'
              },
              {
                id: '4',
                question: 'What is informational social influence?',
                options: ['Desire to be liked', 'Fear of punishment', 'Desire to be correct', 'Need for power'],
                correctAnswer: 2,
                explanation: 'Informational social influence occurs when people conform because they believe the group is correct.'
              },
              {
                id: '5',
                question: 'What is cognitive dissonance?',
                options: ['Mental harmony', 'Discomfort from conflicting beliefs', 'Clear thinking', 'Agreement'],
                correctAnswer: 1,
                explanation: 'Cognitive dissonance is psychological discomfort from holding contradictory beliefs.'
              },
              {
                id: '6',
                question: 'What is the bystander effect?',
                options: ['More likely to help in groups', 'Less likely to help when others present', 'Always helping', 'Ignoring emergencies'],
                correctAnswer: 1,
                explanation: 'The bystander effect shows people are less likely to help when others are present.'
              },
              {
                id: '7',
                question: 'What is social facilitation?',
                options: ['Working worse with others', 'Improved performance with audience', 'Decreased motivation', 'Group conflict'],
                correctAnswer: 1,
                explanation: 'Social facilitation is improved performance on simple tasks when others are watching.'
              },
              {
                id: '8',
                question: 'What is groupthink?',
                options: ['Effective brainstorming', 'Individual decisions', 'Prioritizing consensus over critical thinking', 'Healthy debate'],
                correctAnswer: 2,
                explanation: 'Groupthink occurs when desire for harmony leads to poor decision-making.'
              },
              {
                id: '9',
                question: 'What is social loafing?',
                options: ['Working harder in groups', 'Reduced effort in group tasks', 'Taking breaks', 'Helping others'],
                correctAnswer: 1,
                explanation: 'Social loafing is the tendency to exert less effort when working in groups.'
              },
              {
                id: '10',
                question: 'What is deindividuation?',
                options: ['Strong self-awareness', 'Loss of self-awareness in groups', 'Individual thinking', 'Personal responsibility'],
                correctAnswer: 1,
                explanation: 'Deindividuation is reduced self-awareness and personal accountability in group situations.'
              }
            ]
          }
        ]
      },
      {
        id: 'hr-development',
        name: 'Human Resources & Development',
        icon: 'users',
        color: 'blue',
        topics: [
          {
            id: 'hr-basics',
            name: 'HR Fundamentals',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is human resource development?',
                options: ['Hiring only', 'Organized learning to improve performance', 'Firing employees', 'Payroll management'],
                correctAnswer: 1,
                explanation: 'HRD is organized learning experiences to improve performance and personal growth.'
              },
              {
                id: '2',
                question: 'What is training needs analysis?',
                options: ['Random training', 'Identifying performance gaps', 'Hiring process', 'Salary review'],
                correctAnswer: 1,
                explanation: 'Training needs analysis identifies gaps between current and desired performance.'
              },
              {
                id: '3',
                question: 'What is employee engagement?',
                options: ['Just showing up', 'Emotional commitment to organization', 'Working hours', 'Salary level'],
                correctAnswer: 1,
                explanation: 'Employee engagement is the emotional commitment and involvement employees have toward their organization.'
              },
              {
                id: '4',
                question: 'What is succession planning?',
                options: ['Firing plan', 'Identifying and developing future leaders', 'Retirement', 'Hiring'],
                correctAnswer: 1,
                explanation: 'Succession planning identifies and develops employees to fill key positions in the future.'
              },
              {
                id: '5',
                question: 'What is performance appraisal?',
                options: ['Punishment', 'Systematic evaluation of performance', 'Salary only', 'Hiring decision'],
                correctAnswer: 1,
                explanation: 'Performance appraisal is systematic evaluation of an employee\'s job performance.'
              },
              {
                id: '6',
                question: 'What is organizational development?',
                options: ['Building expansion', 'Planned change to improve effectiveness', 'Hiring more staff', 'Profit increase'],
                correctAnswer: 1,
                explanation: 'Organizational development is planned, systematic change to improve organizational effectiveness.'
              },
              {
                id: '7',
                question: 'What is competency mapping?',
                options: ['Geographic mapping', 'Identifying skills needed for roles', 'Career path', 'Organizational chart'],
                correctAnswer: 1,
                explanation: 'Competency mapping identifies the knowledge, skills, and abilities required for specific roles.'
              },
              {
                id: '8',
                question: 'What is talent management?',
                options: ['Art management', 'Attracting, developing, and retaining talent', 'Entertainment', 'Skills only'],
                correctAnswer: 1,
                explanation: 'Talent management involves attracting, developing, and retaining high-potential employees.'
              },
              {
                id: '9',
                question: 'What is career development?',
                options: ['Just promotions', 'Ongoing progression in work life', 'First job only', 'Retirement planning'],
                correctAnswer: 1,
                explanation: 'Career development is the ongoing process of managing learning, work, and transitions throughout one\'s career.'
              },
              {
                id: '10',
                question: 'What is knowledge management?',
                options: ['Library management', 'Creating, sharing, and using organizational knowledge', 'Education only', 'Data storage'],
                correctAnswer: 1,
                explanation: 'Knowledge management is the process of creating, sharing, using, and managing organizational knowledge.'
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'year2',
    name: 'Year 2',
    subjects: [
      {
        id: 'abnormal-psych',
        name: 'Abnormal Psychology',
        icon: 'heart',
        color: 'red',
        topics: [
          {
            id: 'disorders',
            name: 'Psychological Disorders',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is the most common anxiety disorder?',
                options: ['Panic disorder', 'Specific phobia', 'Social anxiety', 'GAD'],
                correctAnswer: 1,
                explanation: 'Specific phobias are the most common anxiety disorders, affecting about 12% of people.'
              },
              {
                id: '2',
                question: 'Which neurotransmitter is most associated with depression?',
                options: ['Dopamine', 'Serotonin', 'GABA', 'Acetylcholine'],
                correctAnswer: 1,
                explanation: 'Serotonin deficiency is strongly associated with depression.'
              },
              {
                id: '3',
                question: 'What characterizes OCD?',
                options: ['Sadness', 'Intrusive thoughts and repetitive behaviors', 'Multiple personalities', 'Memory loss'],
                correctAnswer: 1,
                explanation: 'OCD involves obsessions (intrusive thoughts) and compulsions (repetitive behaviors).'
              },
              {
                id: '4',
                question: 'What is the diathesis-stress model?',
                options: ['Purely genetic', 'Purely environmental', 'Genetic vulnerability + stress', 'Imaginary'],
                correctAnswer: 2,
                explanation: 'The diathesis-stress model proposes disorders develop from genetic predisposition plus stress.'
              },
              {
                id: '5',
                question: 'What is agoraphobia?',
                options: ['Fear of spiders', 'Fear of heights', 'Fear of open/public spaces', 'Fear of water'],
                correctAnswer: 2,
                explanation: 'Agoraphobia is anxiety about being in situations where escape might be difficult.'
              },
              {
                id: '6',
                question: 'What is a hallucination?',
                options: ['False belief', 'Perception without stimulus', 'Memory error', 'Mood change'],
                correctAnswer: 1,
                explanation: 'A hallucination is a sensory perception without an external stimulus.'
              },
              {
                id: '7',
                question: 'What is a delusion?',
                options: ['Sensory perception', 'False belief despite evidence', 'Mood disorder', 'Anxiety'],
                correctAnswer: 1,
                explanation: 'A delusion is a false belief maintained despite contradictory evidence.'
              },
              {
                id: '8',
                question: 'What characterizes major depressive disorder?',
                options: ['Brief sadness', 'Persistent low mood and loss of interest', 'Mood swings', 'High energy'],
                correctAnswer: 1,
                explanation: 'MDD involves persistent depressed mood and/or loss of interest for at least 2 weeks.'
              },
              {
                id: '9',
                question: 'What is bipolar disorder?',
                options: ['Only depression', 'Alternating manic and depressive episodes', 'Constant anxiety', 'Memory problems'],
                correctAnswer: 1,
                explanation: 'Bipolar disorder involves alternating periods of mania and depression.'
              },
              {
                id: '10',
                question: 'What is PTSD?',
                options: ['Fear of trauma', 'Disorder following traumatic experience', 'Personality disorder', 'Learning disability'],
                correctAnswer: 1,
                explanation: 'PTSD can develop after exposure to traumatic events.'
              }
            ]
          }
        ]
      },
      {
        id: 'training-program',
        name: 'Design & Management of Training Program',
        icon: 'lightbulb',
        color: 'orange',
        topics: [
          {
            id: 'training-design',
            name: 'Training Program Design',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is the first step in training design?',
                options: ['Delivery', 'Needs assessment', 'Evaluation', 'Celebration'],
                correctAnswer: 1,
                explanation: 'Needs assessment identifies performance gaps and training requirements.'
              },
              {
                id: '2',
                question: 'What is ADDIE model?',
                options: ['A person', 'Analysis, Design, Development, Implementation, Evaluation', 'A company', 'A theory'],
                correctAnswer: 1,
                explanation: 'ADDIE is a systematic instructional design framework with five phases.'
              },
              {
                id: '3',
                question: 'What are learning objectives?',
                options: ['General goals', 'Specific, measurable learning outcomes', 'Company goals', 'Attendance'],
                correctAnswer: 1,
                explanation: 'Learning objectives are specific, measurable statements of what learners will be able to do.'
              },
              {
                id: '4',
                question: 'What is transfer of training?',
                options: ['Moving locations', 'Applying learning to the job', 'Changing trainers', 'Switching programs'],
                correctAnswer: 1,
                explanation: 'Transfer of training is the effective application of learned skills to the workplace.'
              },
              {
                id: '5',
                question: 'What is Kirkpatrick\'s evaluation model?',
                options: ['2 levels', '4 levels: Reaction, Learning, Behavior, Results', '6 levels', '1 level'],
                correctAnswer: 1,
                explanation: 'Kirkpatrick\'s model evaluates training at 4 levels: reaction, learning, behavior, and results.'
              },
              {
                id: '6',
                question: 'What is experiential learning?',
                options: ['Reading only', 'Learning through experience and reflection', 'Lectures only', 'Testing only'],
                correctAnswer: 1,
                explanation: 'Experiential learning involves learning through concrete experience, reflection, and application.'
              },
              {
                id: '7',
                question: 'What is a training module?',
                options: ['Classroom only', 'Self-contained instructional unit', 'Entire program', 'Assessment'],
                correctAnswer: 1,
                explanation: 'A training module is a self-contained unit covering a specific topic or skill.'
              },
              {
                id: '8',
                question: 'What is formative evaluation?',
                options: ['Final assessment', 'Ongoing assessment during development', 'After training', 'Never'],
                correctAnswer: 1,
                explanation: 'Formative evaluation occurs during training development to improve the program.'
              },
              {
                id: '9',
                question: 'What is summative evaluation?',
                options: ['During training', 'After training completion', 'Before training', 'Continuous'],
                correctAnswer: 1,
                explanation: 'Summative evaluation assesses the overall effectiveness after training is completed.'
              },
              {
                id: '10',
                question: 'What is blended learning?',
                options: ['Online only', 'Combination of online and face-to-face', 'Classroom only', 'No structure'],
                correctAnswer: 1,
                explanation: 'Blended learning combines online digital media with traditional face-to-face instruction.'
              }
            ]
          }
        ]
      },
      {
        id: 'psych-learning',
        name: 'Psychology of Learning',
        icon: 'brain',
        color: 'purple',
        topics: [
          {
            id: 'learning-theories',
            name: 'Learning Theories',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is classical conditioning?',
                options: ['Rewards', 'Learning through association', 'Observation', 'Insight'],
                correctAnswer: 1,
                explanation: 'Classical conditioning is learning through association between stimuli (Pavlov\'s dogs).'
              },
              {
                id: '2',
                question: 'What is operant conditioning?',
                options: ['Association', 'Learning through consequences', 'Observation', 'Reading'],
                correctAnswer: 1,
                explanation: 'Operant conditioning is learning through rewards and punishments (Skinner).'
              },
              {
                id: '3',
                question: 'What is positive reinforcement?',
                options: ['Removing something unpleasant', 'Adding something pleasant', 'Punishment', 'Ignoring'],
                correctAnswer: 1,
                explanation: 'Positive reinforcement adds a pleasant consequence to increase behavior.'
              },
              {
                id: '4',
                question: 'What is negative reinforcement?',
                options: ['Punishment', 'Removing something unpleasant to increase behavior', 'Adding pain', 'Ignoring'],
                correctAnswer: 1,
                explanation: 'Negative reinforcement removes an aversive stimulus to increase behavior.'
              },
              {
                id: '5',
                question: 'What is observational learning?',
                options: ['Reading', 'Learning by watching others', 'Classical conditioning', 'Trial and error'],
                correctAnswer: 1,
                explanation: 'Observational learning occurs by watching and imitating others (Bandura).'
              },
              {
                id: '6',
                question: 'What is extinction in conditioning?',
                options: ['Strengthening', 'Weakening of conditioned response', 'Punishment', 'Reinforcement'],
                correctAnswer: 1,
                explanation: 'Extinction is the gradual weakening of a conditioned response when reinforcement stops.'
              },
              {
                id: '7',
                question: 'What is spontaneous recovery?',
                options: ['Initial learning', 'Reappearance of extinguished response', 'New learning', 'Forgetting'],
                correctAnswer: 1,
                explanation: 'Spontaneous recovery is the reappearance of an extinguished conditioned response.'
              },
              {
                id: '8',
                question: 'What is generalization?',
                options: ['Specific response', 'Responding to similar stimuli', 'Extinction', 'Discrimination'],
                correctAnswer: 1,
                explanation: 'Generalization is responding to stimuli similar to the conditioned stimulus.'
              },
              {
                id: '9',
                question: 'What is discrimination in learning?',
                options: ['Bias', 'Distinguishing between similar stimuli', 'Generalization', 'Extinction'],
                correctAnswer: 1,
                explanation: 'Discrimination is learning to respond differently to similar but distinct stimuli.'
              },
              {
                id: '10',
                question: 'What is latent learning?',
                options: ['Immediate display', 'Learning without obvious reinforcement', 'No learning', 'Visible learning'],
                correctAnswer: 1,
                explanation: 'Latent learning occurs without obvious reinforcement and isn\'t immediately demonstrated.'
              }
            ]
          }
        ]
      },
      {
        id: 'statistics-y2',
        name: 'Statistics',
        icon: 'trending-up',
        color: 'indigo',
        topics: [
          {
            id: 'stats-basics',
            name: 'Statistical Fundamentals',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is the mean?',
                options: ['Middle value', 'Average of all values', 'Most common value', 'Range'],
                correctAnswer: 1,
                explanation: 'The mean is the arithmetic average calculated by summing values and dividing by the count.'
              },
              {
                id: '2',
                question: 'What is the median?',
                options: ['Average', 'Middle value when ordered', 'Most common', 'Range'],
                correctAnswer: 1,
                explanation: 'The median is the middle value when data is arranged in order.'
              },
              {
                id: '3',
                question: 'What is the mode?',
                options: ['Average', 'Middle value', 'Most frequently occurring value', 'Range'],
                correctAnswer: 2,
                explanation: 'The mode is the value that appears most frequently in a dataset.'
              },
              {
                id: '4',
                question: 'What does standard deviation measure?',
                options: ['Central tendency', 'Spread of data', 'Correlation', 'Probability'],
                correctAnswer: 1,
                explanation: 'Standard deviation measures how spread out values are from the mean.'
              },
              {
                id: '5',
                question: 'What is a normal distribution?',
                options: ['Skewed curve', 'Bell-shaped curve', 'Flat line', 'Random pattern'],
                correctAnswer: 1,
                explanation: 'Normal distribution is a symmetric, bell-shaped curve where most values cluster around the mean.'
              },
              {
                id: '6',
                question: 'What is correlation?',
                options: ['Causation', 'Relationship between variables', 'Difference', 'Average'],
                correctAnswer: 1,
                explanation: 'Correlation measures the strength and direction of relationship between two variables.'
              },
              {
                id: '7',
                question: 'What does p < .05 indicate?',
                options: ['No significance', 'Statistical significance', 'Certainty', 'Large effect'],
                correctAnswer: 1,
                explanation: 'p < .05 indicates the results are statistically significant (less than 5% chance of occurring by chance).'
              },
              {
                id: '8',
                question: 'What is a null hypothesis?',
                options: ['Research prediction', 'No effect or difference', 'Alternative', 'Proven fact'],
                correctAnswer: 1,
                explanation: 'The null hypothesis states there is no effect or difference between variables.'
              },
              {
                id: '9',
                question: 'What is variance?',
                options: ['Mean', 'Square of standard deviation', 'Median', 'Mode'],
                correctAnswer: 1,
                explanation: 'Variance is the average squared deviation from the mean, measuring data spread.'
              },
              {
                id: '10',
                question: 'What is the purpose of a t-test?',
                options: ['Describe data', 'Compare two means', 'Measure correlation', 'Calculate average'],
                correctAnswer: 1,
                explanation: 'A t-test compares the means of two groups to determine if they differ significantly.'
              }
            ]
          }
        ]
      },
      {
        id: 'counselling-psych',
        name: 'Counselling Psychology',
        icon: 'heart',
        color: 'pink',
        topics: [
          {
            id: 'counselling-approaches',
            name: 'Counselling Approaches',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is person-centered therapy?',
                options: ['Directive', 'Client-led, non-directive', 'Technique-focused', 'Problem-focused'],
                correctAnswer: 1,
                explanation: 'Person-centered therapy (Rogers) is client-led, emphasizing empathy and unconditional positive regard.'
              },
              {
                id: '2',
                question: 'What is CBT based on?',
                options: ['Unconscious', 'Thoughts influencing emotions and behaviors', 'Past only', 'Biology only'],
                correctAnswer: 1,
                explanation: 'CBT is based on the interconnection of thoughts, feelings, and behaviors.'
              },
              {
                id: '3',
                question: 'What is systematic desensitization?',
                options: ['Talk therapy', 'Gradual exposure to fears while relaxed', 'Medication', 'Dream analysis'],
                correctAnswer: 1,
                explanation: 'Systematic desensitization gradually exposes clients to feared stimuli while in a relaxed state.'
              },
              {
                id: '4',
                question: 'What is unconditional positive regard?',
                options: ['Judging', 'Accepting without conditions', 'Advice-giving', 'Strict rules'],
                correctAnswer: 1,
                explanation: 'Unconditional positive regard means accepting clients completely without judgment.'
              },
              {
                id: '5',
                question: 'What is the therapeutic alliance?',
                options: ['Contract', 'Collaborative relationship between therapist and client', 'Friendship', 'Business'],
                correctAnswer: 1,
                explanation: 'The therapeutic alliance is the collaborative, trusting relationship between therapist and client.'
              },
              {
                id: '6',
                question: 'What is cognitive restructuring?',
                options: ['Brain surgery', 'Challenging and changing negative thoughts', 'Memory improvement', 'Learning'],
                correctAnswer: 1,
                explanation: 'Cognitive restructuring involves identifying and challenging irrational or negative thoughts.'
              },
              {
                id: '7',
                question: 'What is active listening?',
                options: ['Interrupting', 'Fully concentrating and responding appropriately', 'Giving advice', 'Talking'],
                correctAnswer: 1,
                explanation: 'Active listening involves full attention, understanding, and appropriate reflection.'
              },
              {
                id: '8',
                question: 'What is empathy in counselling?',
                options: ['Sympathy', 'Understanding client\'s emotional experience', 'Agreement', 'Pity'],
                correctAnswer: 1,
                explanation: 'Empathy is understanding and sharing the client\'s emotional experience.'
              },
              {
                id: '9',
                question: 'What is confrontation in counselling?',
                options: ['Being aggressive', 'Gently pointing out discrepancies', 'Arguing', 'Avoiding'],
                correctAnswer: 1,
                explanation: 'Confrontation gently highlights inconsistencies to promote self-awareness.'
              },
              {
                id: '10',
                question: 'What is transference?',
                options: ['Therapist feelings', 'Client redirecting feelings onto therapist', 'Technique', 'Assessment'],
                correctAnswer: 1,
                explanation: 'Transference is when clients redirect feelings about others onto the therapist.'
              }
            ]
          }
        ]
      },
      {
        id: 'multicultural-psych',
        name: 'Multicultural Psychology',
        icon: 'users',
        color: 'green',
        topics: [
          {
            id: 'cultural-competence',
            name: 'Cultural Competence',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is cultural competence?',
                options: ['Knowing all cultures', 'Ability to interact effectively across cultures', 'Speaking languages', 'Traveling'],
                correctAnswer: 1,
                explanation: 'Cultural competence is the ability to interact effectively with people from different cultures.'
              },
              {
                id: '2',
                question: 'What is ethnocentrism?',
                options: ['Cultural appreciation', 'Judging other cultures by one\'s own standards', 'Cultural relativism', 'Diversity'],
                correctAnswer: 1,
                explanation: 'Ethnocentrism is evaluating other cultures based on one\'s own cultural standards.'
              },
              {
                id: '3',
                question: 'What is cultural relativism?',
                options: ['One culture is best', 'Understanding cultures in their own context', 'Ignoring culture', 'Ethnocentrism'],
                correctAnswer: 1,
                explanation: 'Cultural relativism means understanding and evaluating cultures in their own context.'
              },
              {
                id: '4',
                question: 'What is individualism?',
                options: ['Group priority', 'Individual goals prioritized', 'Collectivism', 'Conformity'],
                correctAnswer: 1,
                explanation: 'Individualism emphasizes personal goals and independence over group goals.'
              },
              {
                id: '5',
                question: 'What is collectivism?',
                options: ['Individual goals', 'Group goals prioritized', 'Independence', 'Isolation'],
                correctAnswer: 1,
                explanation: 'Collectivism emphasizes group harmony and interdependence over individual goals.'
              },
              {
                id: '6',
                question: 'What is a microaggression?',
                options: ['Physical violence', 'Brief, subtle discrimination', 'Loud insult', 'Compliment'],
                correctAnswer: 1,
                explanation: 'Microaggressions are brief, subtle expressions of prejudice or discrimination.'
              },
              {
                id: '7',
                question: 'What is acculturation?',
                options: ['Losing culture', 'Adapting to a new culture', 'Rejecting culture', 'No change'],
                correctAnswer: 1,
                explanation: 'Acculturation is the process of cultural change from contact with another culture.'
              },
              {
                id: '8',
                question: 'What is bicultural identity?',
                options: ['One culture only', 'Identifying with two cultures', 'No culture', 'Confused identity'],
                correctAnswer: 1,
                explanation: 'Bicultural identity involves identifying with and integrating two cultural backgrounds.'
              },
              {
                id: '9',
                question: 'What is cultural humility?',
                options: ['Knowing everything', 'Lifelong learning and self-reflection about culture', 'Superiority', 'Ignorance'],
                correctAnswer: 1,
                explanation: 'Cultural humility involves lifelong learning, self-reflection, and recognizing power imbalances.'
              },
              {
                id: '10',
                question: 'What is stereotype threat?',
                options: ['Believing stereotypes', 'Anxiety about confirming negative stereotypes', 'Threatening others', 'No impact'],
                correctAnswer: 1,
                explanation: 'Stereotype threat is anxiety about confirming negative stereotypes about one\'s group.'
              }
            ]
          }
        ]
      },
      {
        id: 'physiological-psych',
        name: 'Physiological Psychology',
        icon: 'activity',
        color: 'orange',
        topics: [
          {
            id: 'brain-behavior',
            name: 'Brain and Behavior',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is the function of neurotransmitters?',
                options: ['Store genes', 'Transmit signals between neurons', 'Protect brain', 'Generate energy'],
                correctAnswer: 1,
                explanation: 'Neurotransmitters are chemical messengers that transmit signals across synapses.'
              },
              {
                id: '2',
                question: 'What is the sympathetic nervous system responsible for?',
                options: ['Rest and digest', 'Fight or flight response', 'Sleep', 'Memory'],
                correctAnswer: 1,
                explanation: 'The sympathetic nervous system activates the fight-or-flight response to stress.'
              },
              {
                id: '3',
                question: 'What does the parasympathetic nervous system do?',
                options: ['Fight or flight', 'Rest and digest', 'Stress response', 'Alertness'],
                correctAnswer: 1,
                explanation: 'The parasympathetic nervous system promotes rest, relaxation, and digestion.'
              },
              {
                id: '4',
                question: 'What is the function of the hypothalamus?',
                options: ['Vision', 'Regulates homeostasis, hunger, thirst, temperature', 'Memory', 'Language'],
                correctAnswer: 1,
                explanation: 'The hypothalamus regulates homeostasis including hunger, thirst, body temperature, and sleep.'
              },
              {
                id: '5',
                question: 'What is the endocrine system?',
                options: ['Nervous system', 'Hormone-secreting glands', 'Digestive system', 'Circulatory system'],
                correctAnswer: 1,
                explanation: 'The endocrine system consists of glands that secrete hormones into the bloodstream.'
              },
              {
                id: '6',
                question: 'What is cortisol?',
                options: ['Happiness hormone', 'Stress hormone', 'Sleep hormone', 'Hunger hormone'],
                correctAnswer: 1,
                explanation: 'Cortisol is a hormone released during stress that helps the body respond to threats.'
              },
              {
                id: '7',
                question: 'What is the function of the cerebellum?',
                options: ['Emotion', 'Motor coordination and balance', 'Vision', 'Language'],
                correctAnswer: 1,
                explanation: 'The cerebellum coordinates movement, balance, and motor learning.'
              },
              {
                id: '8',
                question: 'What is the blood-brain barrier?',
                options: ['Brain membrane', 'Protective filter for brain', 'Blood vessel', 'Neuron layer'],
                correctAnswer: 1,
                explanation: 'The blood-brain barrier protects the brain by filtering substances from the bloodstream.'
              },
              {
                id: '9',
                question: 'What is an action potential?',
                options: ['A thought', 'Electrical signal in neurons', 'Brain wave', 'Neurotransmitter'],
                correctAnswer: 1,
                explanation: 'An action potential is a brief electrical charge that travels along a neuron\'s axon.'
              },
              {
                id: '10',
                question: 'What is the reticular formation?',
                options: ['Eye part', 'Network regulating arousal and attention', 'Memory structure', 'Emotion center'],
                correctAnswer: 1,
                explanation: 'The reticular formation regulates arousal, attention, and sleep-wake cycles.'
              }
            ]
          }
        ]
      },
      {
        id: 'personality-y2',
        name: 'Personality and Individual Differences',
        icon: 'users',
        color: 'purple',
        topics: [
          {
            id: 'personality-theories',
            name: 'Personality Theories',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What are the Big Five personality traits?',
                options: ['SMART', 'OCEAN (Openness, Conscientiousness, Extraversion, Agreeableness, Neuroticism)', 'ABCDE', 'TEAMS'],
                correctAnswer: 1,
                explanation: 'The Big Five are Openness, Conscientiousness, Extraversion, Agreeableness, and Neuroticism.'
              },
              {
                id: '2',
                question: 'What does the id represent in Freud\'s theory?',
                options: ['Moral conscience', 'Pleasure principle, unconscious urges', 'Reality mediator', 'Conscious mind'],
                correctAnswer: 1,
                explanation: 'The id operates on the pleasure principle and contains unconscious drives and urges.'
              },
              {
                id: '3',
                question: 'What does the superego represent?',
                options: ['Urges', 'Moral conscience and ideals', 'Reality', 'Mediator'],
                correctAnswer: 1,
                explanation: 'The superego represents internalized moral standards and ideals from parents and society.'
              },
              {
                id: '4',
                question: 'What does the ego do?',
                options: ['Pure pleasure', 'Mediates between id and superego using reality', 'Morality only', 'Unconscious only'],
                correctAnswer: 1,
                explanation: 'The ego operates on the reality principle and mediates between id and superego.'
              },
              {
                id: '5',
                question: 'What is self-actualization?',
                options: ['Basic needs', 'Realizing full potential', 'Safety', 'Survival'],
                correctAnswer: 1,
                explanation: 'Self-actualization is realizing one\'s full potential and becoming the best version of oneself.'
              },
              {
                id: '6',
                question: 'What is a defense mechanism?',
                options: ['Fighting', 'Unconscious strategy to reduce anxiety', 'Conscious plan', 'Attack'],
                correctAnswer: 1,
                explanation: 'Defense mechanisms are unconscious strategies the ego uses to reduce anxiety.'
              },
              {
                id: '7',
                question: 'What is repression?',
                options: ['Remembering', 'Pushing threatening thoughts to unconscious', 'Expressing feelings', 'Conscious forgetting'],
                correctAnswer: 1,
                explanation: 'Repression is pushing anxiety-provoking thoughts and memories into the unconscious.'
              },
              {
                id: '8',
                question: 'What is projection?',
                options: ['Self-awareness', 'Attributing own unacceptable feelings to others', 'Honesty', 'Acceptance'],
                correctAnswer: 1,
                explanation: 'Projection involves attributing one\'s own unacceptable thoughts or feelings to others.'
              },
              {
                id: '9',
                question: 'What is the locus of control?',
                options: ['Brain region', 'Belief about control over life events', 'Personality type', 'Emotion'],
                correctAnswer: 1,
                explanation: 'Locus of control is the degree to which people believe they control events in their lives.'
              },
              {
                id: '10',
                question: 'What is trait theory?',
                options: ['Behavior changes constantly', 'Personality consists of stable characteristics', 'No consistency', 'Situational only'],
                correctAnswer: 1,
                explanation: 'Trait theory proposes that personality consists of stable characteristics that endure over time.'
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'year3',
    name: 'Year 3',
    subjects: [
      {
        id: 'group-dynamics',
        name: 'Group Dynamics',
        icon: 'users',
        color: 'green',
        topics: [
          {
            id: 'scientific-study',
            name: 'Chapter 2: Scientific Study of Groups',
            completed: false,
            questions: [
              {
                id: '1',
                question: '[2 marks] Define sociometry as used in group dynamics research.',
                options: [
                  'A technique for measuring personality traits in groups',
                  'A method for assessing interpersonal relationships and social structures within groups',
                  'A statistical approach for analyzing group performance',
                  'A survey tool for measuring group satisfaction'
                ],
                correctAnswer: 1,
                explanation: 'Sociometry is a quantitative method developed by Moreno for measuring social relationships, particularly choices and rejections among group members, often visualized through sociograms.'
              },
              {
                id: '2',
                question: '[6 marks] Compare and contrast internal validity and external validity in group dynamics research. Provide one example of how each can be compromised.',
                options: [
                  'Internal validity concerns causation within the study; external validity concerns generalizability. Internal can be compromised by confounding variables; external by artificial lab settings.',
                  'Internal validity is about sample size; external validity is about statistical power. Both are compromised by measurement error.',
                  'Internal validity measures reliability; external validity measures accuracy. Both require random sampling.',
                  'Internal validity relates to theory; external validity relates to practice. Neither can be compromised in well-designed studies.'
                ],
                correctAnswer: 0,
                explanation: 'Internal validity refers to the degree to which we can establish causal relationships (threatened by confounds, selection bias). External validity refers to generalizability to other populations, settings, and times (threatened by artificial settings, non-representative samples).'
              },
              {
                id: '3',
                question: '[8 marks] Critically evaluate the use of laboratory experiments versus field research in studying group dynamics. Discuss the trade-offs between experimental control and ecological validity.',
                options: [
                  'Laboratory experiments offer high internal validity through control over variables but may lack ecological validity due to artificial settings. Field research provides realistic contexts but sacrifices experimental control, making causal inference difficult. The trade-off requires researchers to balance rigor with real-world applicability.',
                  'Laboratory experiments are always superior because they provide definitive causal evidence. Field research is unreliable and should be avoided.',
                  'Field research is more valid because it studies real groups. Laboratory experiments are artificial and tell us nothing useful about actual group behavior.',
                  'Both methods are equally valid and provide identical information. The choice between them is merely a matter of researcher preference.'
                ],
                correctAnswer: 0,
                explanation: 'This answer demonstrates understanding of the internal-external validity trade-off. Lab experiments maximize control and causal inference but may create demand characteristics and artificial situations. Field studies capture natural group processes but introduce confounds and measurement challenges. Good research programs use both approaches complementarily.'
              },
              {
                id: '4',
                question: '[2 marks] According to social identity theory, what is the primary function of social categorization?',
                options: [
                  'To increase working memory capacity',
                  'To simplify social perception and enhance self-esteem through group identification',
                  'To improve individual task performance',
                  'To reduce interpersonal conflict'
                ],
                correctAnswer: 1,
                explanation: 'Tajfel and Turner proposed that social categorization serves to organize the social environment and provides a basis for self-definition and self-esteem through positive distinctiveness of one\'s ingroup.'
              },
              {
                id: '5',
                question: '[10 marks] Explain the levels of analysis approach in group dynamics research (individual, interpersonal, group, organizational). Why is a multilevel perspective important? Use a specific research example to illustrate your answer.',
                options: [
                  'The levels of analysis framework recognizes that group phenomena can be examined at individual (member attributes, perceptions), interpersonal (dyadic relationships), group (emergent properties like cohesion, norms), and organizational levels. A multilevel perspective is crucial because group behavior emerges from complex interactions across levels - individual attitudes aggregate to group climate, which in turn influences individual behavior (cross-level effects). Example: Groupthink involves individual cognitive biases, interpersonal pressure to conform, group-level cohesion and structural faults, and organizational culture emphasizing consensus.',
                  'Levels of analysis simply mean different ways to measure the same thing. A multilevel perspective is not particularly important since all levels provide redundant information.',
                  'Only the group level matters in group dynamics research. Individual and organizational levels are irrelevant to understanding group processes.',
                  'The approach divides research into four separate categories that should never be integrated. Each level requires completely different theories with no connection between them.'
                ],
                correctAnswer: 0,
                explanation: 'This demonstrates sophisticated understanding that group phenomena are multilevel, with emergent properties at higher levels and cross-level influences. The groupthink example shows how individual cognition, interpersonal dynamics, group structure, and organizational context interact to produce the phenomenon.'
              }
            ]
          },
          {
            id: 'inclusion-identity',
            name: 'Chapter 3: Inclusion, Identity, and Formation',
            completed: false,
            questions: [
              {
                id: '1',
                question: '[2 marks] What is the core proposition of Baumeister and Leary\'s belongingness hypothesis?',
                options: [
                  'Humans have a pervasive drive to form and maintain lasting, positive, and significant interpersonal relationships',
                  'People join groups primarily for instrumental benefits',
                  'Group membership is a learned behavior with no evolutionary basis',
                  'The need to belong varies significantly across individuals and cultures'
                ],
                correctAnswer: 0,
                explanation: 'Baumeister and Leary (1995) proposed that the need to belong is a fundamental human motivation, evolutionarily adaptive, universal, and essential for well-being.'
              },
              {
                id: '2',
                question: '[6 marks] Describe Tajfel and Turner\'s social identity theory. Explain the three cognitive processes involved and how they relate to ingroup favoritism.',
                options: [
                  'Social identity theory proposes that group membership contributes to self-concept and self-esteem. Three processes: (1) Social categorization - dividing people into ingroups and outgroups; (2) Social identification - adopting the identity and norms of groups we belong to; (3) Social comparison - comparing our groups favorably to others. These processes lead to ingroup favoritism as individuals seek positive distinctiveness to enhance self-esteem.',
                  'Social identity theory states that people have multiple identities that never interact. The three processes are perception, memory, and attention. Ingroup favoritism is unrelated to these processes.',
                  'The theory explains individual personality development through three stages: childhood, adolescence, and adulthood. Ingroup favoritism is a personality disorder.',
                  'Social identity theory only applies to large organizations, not small groups. The three processes are hiring, training, and promotion.'
                ],
                correctAnswer: 0,
                explanation: 'Correct answer captures the essence of SIT - that social identities are part of self-concept, derived through categorization, identification, and comparison processes, leading to motivated ingroup bias to maintain positive social identity and self-esteem.'
              },
              {
                id: '3',
                question: '[12 marks] Using Moreland and Levine\'s model of group socialization, trace the stages an individual experiences from initial contact with a group through to exit. For each stage, identify the key transition point, the relationship between the individual and group, and provide a concrete example from a university psychology student joining a research lab.',
                options: [
                  'The model includes five stages: (1) INVESTIGATION (prospective member) - individual and group evaluate each other, transition at entry criterion; Example: Student researches labs, attends presentations; PI assesses fit. (2) SOCIALIZATION (new member) - group tries to change individual, individual tries to change group, transition at acceptance criterion; Example: Student learns lab procedures and norms, proposes new methods. (3) MAINTENANCE (full member) - role negotiation, transition at divergence criterion; Example: Student takes on independent project, disagreement over research direction. (4) RESOCIALIZATION (marginal member) - attempts to restore commitment, transition at exit criterion; Example: Student considers leaving, PI offers new opportunities. (5) REMEMBRANCE (ex-member) - retrospective evaluation; Example: Student reflects on experience after graduation.',
                  'The model has three simple stages: joining, being a member, and leaving. No transitions or evaluations occur. Example: Student joins lab, works there, then graduates.',
                  'Moreland and Levine proposed a linear progression where individuals become increasingly committed over time with no possibility of decreased commitment. Example: Student joins lab and stays forever.',
                  'The model only applies to political groups and has no relevance to academic or organizational contexts. Cannot provide university example.'
                ],
                correctAnswer: 0,
                explanation: 'This comprehensive answer demonstrates deep understanding of the model\'s five stages, commitment dynamics, transition points, and bidirectional influence between individual and group. The concrete example shows application to a realistic scenario with appropriate stage-specific behaviors.'
              },
              {
                id: '4',
                question: '[8 marks] Distinguish between personal identity and social identity according to self-categorization theory (Turner). Explain how the level of self-categorization affects perception and behavior, and discuss the concept of depersonalization.',
                options: [
                  'Personal identity involves self-definition based on unique individual attributes and interpersonal relationships, while social identity involves self-definition based on group memberships and category characteristics. Self-categorization theory proposes that the level at which we categorize ourselves (personal vs. social) is context-dependent and affects cognition and behavior. When social identity is salient, depersonalization occurs - individuals perceive themselves and others as interchangeable group members rather than unique individuals, leading to conformity to group norms and increased intragroup similarity. This is not a loss of identity but a shift to a different level of self-definition.',
                  'Personal and social identity are the same thing and do not affect behavior differently. Depersonalization is a mental illness unrelated to group processes.',
                  'Personal identity is good and social identity is bad. Depersonalization always involves complete loss of self-awareness and should be avoided.',
                  'The theory states that personal identity dominates in all situations. Social identity only matters in collectivist cultures. Depersonalization never occurs in normal individuals.'
                ],
                correctAnswer: 0,
                explanation: 'This answer correctly distinguishes the two levels of identity, explains the functional flexibility of self-categorization, and accurately describes depersonalization as a shift in self-perception (not pathological) that underlies group phenomena like conformity and collective behavior.'
              },
              {
                id: '5',
                question: '[2 marks] Which factor is most strongly associated with initial group formation?',
                options: [
                  'Complementary skills',
                  'Physical proximity',
                  'Shared past experiences',
                  'Similar socioeconomic status'
                ],
                correctAnswer: 1,
                explanation: 'Proximity (propinquity) is consistently found to be the strongest predictor of relationship and group formation, as demonstrated in classic studies like Festinger\'s Westgate housing research. Proximity increases opportunity for interaction, leading to familiarity and liking.'
              }
            ]
          },
          {
            id: 'cohesion-development',
            name: 'Chapter 4: Cohesion and Development',
            completed: false,
            questions: [
              {
                id: '1',
                question: '[2 marks] Define group cohesion.',
                options: [
                  'The total number of members in a group',
                  'The forces that bind group members together and create a sense of belonging and commitment',
                  'The leadership style employed in the group',
                  'The formal rules and regulations of the group'
                ],
                correctAnswer: 1,
                explanation: 'Cohesion refers to the resultant forces that attract members to the group and resist disruptive forces. It encompasses both task cohesion (commitment to group goals) and social cohesion (interpersonal attraction).'
              },
              {
                id: '2',
                question: '[6 marks] Describe Tuckman\'s five-stage model of group development. For each stage, identify the primary focus and one characteristic behavior.',
                options: [
                  'FORMING - Focus: Orientation and inclusion; Behavior: Polite interaction, testing boundaries. STORMING - Focus: Conflict and power struggles; Behavior: Disagreements about goals and procedures. NORMING - Focus: Establishing structure and cohesion; Behavior: Developing shared norms and increased cooperation. PERFORMING - Focus: Task accomplishment; Behavior: Productive work toward goals. ADJOURNING - Focus: Dissolution; Behavior: Reflection and emotional responses to ending.',
                  'The stages are planning, implementing, evaluating, and finishing. Each focuses on productivity and involves working harder.',
                  'Tuckman proposed three stages: beginning, middle, and end. Groups simply start, continue, and stop.',
                  'The model includes ten complex stages that groups must complete in exact order or the group fails completely.'
                ],
                correctAnswer: 0,
                explanation: 'Tuckman\'s (1965) model proposes sequential stages of group development, later adding adjourning. Each stage involves different interpersonal and task challenges that groups must navigate for optimal development.'
              },
              {
                id: '3',
                question: '[10 marks] Compare and contrast Tuckman\'s linear stage model with Gersick\'s punctuated equilibrium model of group development. Under what conditions might each model better describe group development? Support your answer with empirical evidence.',
                options: [
                  'Tuckman proposes sequential stages (forming→storming→norming→performing→adjourning) with gradual progression. Gersick proposes periods of inertia punctuated by revolutionary change at the temporal midpoint. Evidence: Gersick studied project teams with deadlines and found consistent midpoint transitions regardless of total time available, suggesting time awareness triggers change. Tuckman\'s model better describes groups without fixed deadlines or those meeting repeatedly over extended periods. Gersick\'s model better describes project teams with deadlines where time pressure creates awareness and urgency. Both models have empirical support but may describe different types of groups or focus on different aspects of development (interpersonal vs. task).',
                  'Both models are identical and propose the same stages. There are no differences between them and both apply equally to all groups.',
                  'Tuckman\'s model is completely wrong and has no empirical support. Only Gersick\'s model is correct and applies to all groups universally.',
                  'Group development is random and unpredictable. Neither model has any validity and groups cannot be studied scientifically.'
                ],
                correctAnswer: 0,
                explanation: 'This answer demonstrates sophisticated understanding of both models, their key differences (linear vs. punctuated change), empirical basis, and boundary conditions. It shows critical thinking about when each model applies rather than treating either as universally true.'
              },
              {
                id: '4',
                question: '[8 marks] Discuss the relationship between group cohesion and group performance. Is high cohesion always beneficial? Explain the moderating role of performance norms and provide examples.',
                options: [
                  'The cohesion-performance relationship is complex and curvilinear, moderated by performance norms. When cohesion is high and performance norms are positive (valuing productivity), performance is maximized. However, when cohesion is high but performance norms are negative (restricting output), cohesive groups may perform worse than non-cohesive groups due to stronger pressure to conform to low-productivity norms. Meta-analyses (e.g., Mullen & Copper) show bidirectional effects: cohesion→performance and performance→cohesion. Examples: Highly cohesive surgical teams with excellence norms show superior outcomes; highly cohesive work groups with anti-management norms may engage in collective restriction of output. Extremely high cohesion can also create groupthink, impairing decision quality.',
                  'High cohesion always leads to high performance in all situations without exception. More cohesion is always better.',
                  'Cohesion and performance are completely unrelated. Cohesion has no effect on what groups accomplish.',
                  'Cohesion only matters in sports teams and is irrelevant to other types of groups. Performance norms do not exist.'
                ],
                correctAnswer: 0,
                explanation: 'This answer shows nuanced understanding that cohesion\'s effects depend on norms, acknowledges bidirectional causality and curvilinear relationships, cites meta-analytic evidence, provides concrete examples, and recognizes potential downsides of excessive cohesion (groupthink).'
              },
              {
                id: '5',
                question: '[12 marks] Critically evaluate methods for measuring group cohesion. Discuss the strengths and limitations of at least three different approaches (e.g., sociometric methods, self-report questionnaires, behavioral observation). Which method would you recommend for measuring cohesion in a university project team and why?',
                options: [
                  'SOCIOMETRIC METHODS (e.g., asking who you would like to work with): Strengths - captures actual interpersonal attractions and network structure; Limitations - time-consuming, may miss task cohesion, social desirability bias. SELF-REPORT QUESTIONNAIRES (e.g., GEQ - Group Environment Questionnaire): Strengths - efficient, can assess multiple dimensions (task/social cohesion), established reliability/validity; Limitations - subjective perceptions may not match behavioral reality, common method variance. BEHAVIORAL OBSERVATION (e.g., coding cooperative behaviors, proximity): Strengths - objective, captures actual behavior not just attitudes; Limitations - labor-intensive, observer bias, presence of observer may alter behavior, difficult to infer psychological states from behavior. RECOMMENDATION for university project team: GEQ self-report supplemented by sociometric choice data. Rationale: GEQ provides efficient assessment of both task and social cohesion dimensions relevant to project success; sociometric data reveals subgroup formation and potential conflict. Behavioral observation is too resource-intensive for this context. Combining methods provides triangulation and more complete picture.',
                  'All measurement methods are equally valid and provide identical information. Just pick any method randomly. Self-report is always perfect and completely accurate.',
                  'Only behavioral observation is valid because people always lie on questionnaires. Never use self-report measures under any circumstances.',
                  'Cohesion cannot be measured scientifically. Any attempt to quantify it is fundamentally flawed. No method should be recommended.'
                ],
                correctAnswer: 0,
                explanation: 'This comprehensive answer demonstrates deep understanding of measurement issues, correctly identifies strengths and limitations of multiple approaches, shows awareness of the multidimensional nature of cohesion, and provides a thoughtful, justified recommendation using methodological triangulation appropriate to the specific context.'
              }
            ]
          }
        ]
      },
      {
        id: 'clinical-psych',
        name: 'Clinical Psychology',
        icon: 'heart',
        color: 'red',
        topics: [
          {
            id: 'assessment',
            name: 'Clinical Assessment',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is a clinical interview?',
                options: ['Job interview', 'Conversation to gather information about client', 'Test', 'Observation'],
                correctAnswer: 1,
                explanation: 'A clinical interview is a structured conversation to gather information about the client\'s history and symptoms.'
              },
              {
                id: '2',
                question: 'What is the MMPI?',
                options: ['Interview', 'Personality assessment inventory', 'IQ test', 'Projective test'],
                correctAnswer: 1,
                explanation: 'The MMPI (Minnesota Multiphasic Personality Inventory) is a widely used personality assessment.'
              },
              {
                id: '3',
                question: 'What is a projective test?',
                options: ['Multiple choice', 'Ambiguous stimuli to reveal unconscious', 'Structured', 'IQ test'],
                correctAnswer: 1,
                explanation: 'Projective tests use ambiguous stimuli to reveal unconscious thoughts and feelings.'
              },
              {
                id: '4',
                question: 'What is the DSM-5?',
                options: ['Treatment manual', 'Diagnostic classification system', 'Theory book', 'Research method'],
                correctAnswer: 1,
                explanation: 'The DSM-5 is the Diagnostic and Statistical Manual used for classifying mental disorders.'
              },
              {
                id: '5',
                question: 'What is differential diagnosis?',
                options: ['One diagnosis', 'Distinguishing between similar conditions', 'Treatment', 'Assessment tool'],
                correctAnswer: 1,
                explanation: 'Differential diagnosis involves distinguishing between disorders with similar symptoms.'
              },
              {
                id: '6',
                question: 'What is comorbidity?',
                options: ['Death', 'Multiple concurrent disorders', 'One disorder', 'Recovery'],
                correctAnswer: 1,
                explanation: 'Comorbidity is the presence of two or more disorders occurring together.'
              },
              {
                id: '7',
                question: 'What is behavioral observation?',
                options: ['Interview', 'Watching and recording behavior', 'Testing', 'Diagnosis'],
                correctAnswer: 1,
                explanation: 'Behavioral observation involves systematically watching and recording behavior.'
              },
              {
                id: '8',
                question: 'What is a functional analysis?',
                options: ['Brain scan', 'Identifying antecedents and consequences of behavior', 'Diagnosis', 'Treatment'],
                correctAnswer: 1,
                explanation: 'Functional analysis identifies what triggers and maintains problem behaviors.'
              },
              {
                id: '9',
                question: 'What is treatment fidelity?',
                options: ['Client loyalty', 'Adherence to treatment protocol', 'Success rate', 'Diagnosis accuracy'],
                correctAnswer: 1,
                explanation: 'Treatment fidelity is the degree to which treatment is delivered as intended.'
              },
              {
                id: '10',
                question: 'What is evidence-based practice?',
                options: ['Personal opinion', 'Using research-supported treatments', 'Traditional methods', 'Trial and error'],
                correctAnswer: 1,
                explanation: 'Evidence-based practice uses treatments supported by scientific research.'
              }
            ]
          }
        ]
      },
      {
        id: 'io-psych',
        name: 'Industrial/Organisational Psychology',
        icon: 'briefcase',
        color: 'blue',
        topics: [
          {
            id: 'workplace',
            name: 'Workplace Psychology',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What influences job satisfaction?',
                options: ['Salary only', 'Work environment, relationships, fulfillment', 'Office size', 'Company name'],
                correctAnswer: 1,
                explanation: 'Job satisfaction is influenced by multiple factors including relationships and fulfillment.'
              },
              {
                id: '2',
                question: 'What is organizational commitment?',
                options: ['Long hours', 'Psychological attachment to organization', 'Punctuality', 'Following rules'],
                correctAnswer: 1,
                explanation: 'Organizational commitment is psychological attachment and identification with the organization.'
              },
              {
                id: '3',
                question: 'What is the Hawthorne effect?',
                options: ['Light improves work', 'Observation changes behavior', 'Money motivates', 'Groups work slowly'],
                correctAnswer: 1,
                explanation: 'The Hawthorne effect shows that being observed changes behavior.'
              },
              {
                id: '4',
                question: 'What is burnout?',
                options: ['Brief fatigue', 'Chronic work stress and exhaustion', 'Excitement', 'Job change'],
                correctAnswer: 1,
                explanation: 'Burnout is chronic exhaustion, cynicism, and reduced efficacy from work stress.'
              },
              {
                id: '5',
                question: 'What is transformational leadership?',
                options: ['Transactional rewards', 'Inspiring and motivating followers', 'Authoritarian', 'Passive'],
                correctAnswer: 1,
                explanation: 'Transformational leadership inspires and motivates followers to achieve extraordinary outcomes.'
              },
              {
                id: '6',
                question: 'What is job analysis?',
                options: ['Performance review', 'Identifying job requirements and KSAOs', 'Hiring', 'Training'],
                correctAnswer: 1,
                explanation: 'Job analysis identifies the knowledge, skills, abilities, and other characteristics needed for a job.'
              },
              {
                id: '7',
                question: 'What is work-life balance?',
                options: ['Working more', 'Equilibrium between work and personal life', 'Remote work', 'Short hours'],
                correctAnswer: 1,
                explanation: 'Work-life balance is maintaining equilibrium between professional and personal life.'
              },
              {
                id: '8',
                question: 'What is organizational culture?',
                options: ['Company size', 'Shared values and beliefs', 'Office building', 'Salary'],
                correctAnswer: 1,
                explanation: 'Organizational culture consists of shared values, beliefs, and norms in a workplace.'
              },
              {
                id: '9',
                question: 'What is job enrichment?',
                options: ['More pay', 'Adding meaningful responsibility', 'More tasks only', 'Longer hours'],
                correctAnswer: 1,
                explanation: 'Job enrichment adds more meaningful responsibilities and autonomy to a role.'
              },
              {
                id: '10',
                question: 'What is OCB (Organizational Citizenship Behavior)?',
                options: ['Required tasks', 'Voluntary helpful behavior beyond requirements', 'Following rules', 'Training'],
                correctAnswer: 1,
                explanation: 'OCB is voluntary helpful behavior that goes beyond formal job requirements.'
              }
            ]
          }
        ]
      },
      {
        id: 'experimental-psych',
        name: 'Experimental Psychology',
        icon: 'flask',
        color: 'purple',
        topics: [
          {
            id: 'research-design',
            name: 'Research Design',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is the key feature of a true experiment?',
                options: ['Large sample', 'Random assignment to conditions', 'Long duration', 'Multiple researchers'],
                correctAnswer: 1,
                explanation: 'Random assignment is the hallmark of true experiments, allowing causal conclusions.'
              },
              {
                id: '2',
                question: 'What is a confounding variable?',
                options: ['DV', 'IV', 'Unmeasured variable affecting results', 'Control variable'],
                correctAnswer: 2,
                explanation: 'A confounding variable is an extraneous factor that affects both IV and DV.'
              },
              {
                id: '3',
                question: 'What is counterbalancing?',
                options: ['Increasing sample', 'Controlling order effects', 'Measuring variables', 'Analyzing data'],
                correctAnswer: 1,
                explanation: 'Counterbalancing controls for order effects by varying condition sequences.'
              },
              {
                id: '4',
                question: 'What is a within-subjects design?',
                options: ['Different participants per condition', 'Same participants in all conditions', 'Large sample', 'No control'],
                correctAnswer: 1,
                explanation: 'Within-subjects designs use the same participants in all experimental conditions.'
              },
              {
                id: '5',
                question: 'What is internal validity?',
                options: ['Generalizability', 'Degree to which IV caused DV changes', 'Sample size', 'Power'],
                correctAnswer: 1,
                explanation: 'Internal validity is the extent to which the IV actually caused changes in the DV.'
              },
              {
                id: '6',
                question: 'What is external validity?',
                options: ['Causation', 'Generalizability to other situations', 'Consistency', 'Significance'],
                correctAnswer: 1,
                explanation: 'External validity is the degree to which findings generalize to other contexts.'
              },
              {
                id: '7',
                question: 'What is a manipulation check?',
                options: ['Sample check', 'Verifying IV was successfully manipulated', 'Data analysis', 'Ethics review'],
                correctAnswer: 1,
                explanation: 'A manipulation check verifies that the independent variable was successfully manipulated.'
              },
              {
                id: '8',
                question: 'What is a pilot study?',
                options: ['Final study', 'Small preliminary study', 'Large survey', 'Meta-analysis'],
                correctAnswer: 1,
                explanation: 'A pilot study is a small preliminary study to test procedures.'
              },
              {
                id: '9',
                question: 'What is ecological validity?',
                options: ['Lab precision', 'Real-world applicability', 'Sample size', 'Power'],
                correctAnswer: 1,
                explanation: 'Ecological validity is the extent to which findings apply to real-world settings.'
              },
              {
                id: '10',
                question: 'What is a double-blind study?',
                options: ['Vision test', 'Neither participants nor researchers know conditions', 'Saving money', 'Large sample'],
                correctAnswer: 1,
                explanation: 'In double-blind studies, neither participants nor researchers know who is in which condition.'
              }
            ]
          }
        ]
      },
      {
        id: 'psych-ethics',
        name: 'Psychology Ethics',
        icon: 'lightbulb',
        color: 'indigo',
        topics: [
          {
            id: 'ethical-principles',
            name: 'Ethical Principles',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is informed consent?',
                options: ['Paying participants', 'Voluntary agreement after understanding', 'Confidentiality', 'Publishing'],
                correctAnswer: 1,
                explanation: 'Informed consent means participants voluntarily agree after being fully informed.'
              },
              {
                id: '2',
                question: 'What are the limits of confidentiality?',
                options: ['Never break', 'Harm to self/others, child abuse, court order', 'Always tell', 'No limits'],
                correctAnswer: 1,
                explanation: 'Confidentiality has limits including harm to self/others, child abuse, and court orders.'
              },
              {
                id: '3',
                question: 'What is beneficence?',
                options: ['Do harm', 'Do good and benefit others', 'Ignore clients', 'Personal gain'],
                correctAnswer: 1,
                explanation: 'Beneficence is the ethical principle of doing good and benefiting others.'
              },
              {
                id: '4',
                question: 'What is non-maleficence?',
                options: ['Do harm', 'Do no harm', 'Ignore ethics', 'Personal benefit'],
                correctAnswer: 1,
                explanation: 'Non-maleficence is the principle of doing no harm to clients or research participants.'
              },
              {
                id: '5',
                question: 'What is a dual relationship?',
                options: ['Two therapists', 'Multiple roles with same person', 'Group therapy', 'Team approach'],
                correctAnswer: 1,
                explanation: 'A dual relationship involves having multiple roles with the same person, which should be avoided.'
              },
              {
                id: '6',
                question: 'What is competence in ethics?',
                options: ['Doing everything', 'Practicing within training and expertise', 'Trying new things', 'Ignoring limits'],
                correctAnswer: 1,
                explanation: 'Competence means practicing only within the bounds of one\'s training and expertise.'
              },
              {
                id: '7',
                question: 'What is deception in research?',
                options: ['Always wrong', 'Sometimes justified if debriefed', 'Always acceptable', 'Never happens'],
                correctAnswer: 1,
                explanation: 'Deception may be justified if necessary for research and participants are debriefed afterward.'
              },
              {
                id: '8',
                question: 'What is debriefing?',
                options: ['Initial meeting', 'Explaining study purpose after participation', 'Consent form', 'Payment'],
                correctAnswer: 1,
                explanation: 'Debriefing involves explaining the true purpose of research after participation.'
              },
              {
                id: '9',
                question: 'What is cultural sensitivity?',
                options: ['Ignoring culture', 'Respecting and understanding cultural differences', 'Stereotyping', 'Bias'],
                correctAnswer: 1,
                explanation: 'Cultural sensitivity involves respecting and understanding diverse cultural backgrounds.'
              },
              {
                id: '10',
                question: 'What is the right to withdraw?',
                options: ['No choice', 'Participants can leave anytime', 'Must complete', 'Penalty for leaving'],
                correctAnswer: 1,
                explanation: 'Participants have the right to withdraw from research at any time without penalty.'
              }
            ]
          }
        ]
      },
      {
        id: 'occupational-safety',
        name: 'Occupational Safety and Health',
        icon: 'activity',
        color: 'orange',
        topics: [
          {
            id: 'workplace-safety',
            name: 'Workplace Safety',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is occupational stress?',
                options: ['Any stress', 'Stress arising from work demands', 'Home stress', 'No stress'],
                correctAnswer: 1,
                explanation: 'Occupational stress arises from demands and pressures of the work environment.'
              },
              {
                id: '2',
                question: 'What is ergonomics?',
                options: ['Exercise', 'Designing workplaces to fit workers', 'Decoration', 'Furniture'],
                correctAnswer: 1,
                explanation: 'Ergonomics is designing workplaces and equipment to fit workers and prevent injury.'
              },
              {
                id: '3',
                question: 'What is a psychosocial hazard?',
                options: ['Chemical', 'Work factors affecting mental health', 'Physical danger', 'Noise'],
                correctAnswer: 1,
                explanation: 'Psychosocial hazards are aspects of work that can harm mental health and wellbeing.'
              },
              {
                id: '4',
                question: 'What is workplace bullying?',
                options: ['Friendship', 'Repeated unreasonable behavior causing harm', 'One-time conflict', 'Competition'],
                correctAnswer: 1,
                explanation: 'Workplace bullying is repeated, unreasonable behavior that creates a risk to health and safety.'
              },
              {
                id: '5',
                question: 'What is a safety culture?',
                options: ['Rules only', 'Shared values prioritizing safety', 'Individual responsibility', 'Punishment'],
                correctAnswer: 1,
                explanation: 'Safety culture consists of shared values, beliefs, and practices that prioritize safety.'
              },
              {
                id: '6',
                question: 'What is work-related fatigue?',
                options: ['Laziness', 'Extreme tiredness from work demands', 'Boredom', 'Sleepiness only'],
                correctAnswer: 1,
                explanation: 'Work-related fatigue is extreme tiredness resulting from prolonged physical or mental exertion at work.'
              },
              {
                id: '7',
                question: 'What is a near miss?',
                options: ['Success', 'Incident that could have caused harm but didn\'t', 'Actual injury', 'Achievement'],
                correctAnswer: 1,
                explanation: 'A near miss is an unplanned event that could have resulted in injury but didn\'t.'
              },
              {
                id: '8',
                question: 'What is risk assessment?',
                options: ['Taking risks', 'Identifying and evaluating workplace hazards', 'Ignoring dangers', 'Blaming workers'],
                correctAnswer: 1,
                explanation: 'Risk assessment involves identifying hazards and evaluating the likelihood and severity of harm.'
              },
              {
                id: '9',
                question: 'What is PPE?',
                options: ['Performance evaluation', 'Personal Protective Equipment', 'Payment plan', 'Policy'],
                correctAnswer: 1,
                explanation: 'PPE (Personal Protective Equipment) includes items worn to minimize exposure to hazards.'
              },
              {
                id: '10',
                question: 'What is the hierarchy of controls?',
                options: ['Management levels', 'Prioritized methods to control hazards', 'Salary levels', 'Authority'],
                correctAnswer: 1,
                explanation: 'The hierarchy of controls ranks methods of controlling hazards from most to least effective.'
              }
            ]
          }
        ]
      },
      {
        id: 'psych-testing',
        name: 'Psychology Testing',
        icon: 'trending-up',
        color: 'pink',
        topics: [
          {
            id: 'assessment-tools',
            name: 'Psychological Assessment',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is reliability in testing?',
                options: ['Validity', 'Consistency of measurement', 'Accuracy', 'Speed'],
                correctAnswer: 1,
                explanation: 'Reliability is the consistency and stability of test scores over time and conditions.'
              },
              {
                id: '2',
                question: 'What is validity in testing?',
                options: ['Consistency', 'Test measures what it claims to measure', 'Reliability', 'Length'],
                correctAnswer: 1,
                explanation: 'Validity is the extent to which a test measures what it is intended to measure.'
              },
              {
                id: '3',
                question: 'What is a standardized test?',
                options: ['Informal', 'Administered and scored consistently', 'Unique each time', 'No rules'],
                correctAnswer: 1,
                explanation: 'A standardized test is administered and scored in a consistent, predetermined manner.'
              },
              {
                id: '4',
                question: 'What are norms in testing?',
                options: ['Rules', 'Average performance of reference group', 'Maximum score', 'Instructions'],
                correctAnswer: 1,
                explanation: 'Norms are the average performance of a reference group used for comparison.'
              },
              {
                id: '5',
                question: 'What is an intelligence test?',
                options: ['Personality test', 'Measure of cognitive abilities', 'Achievement test', 'Skill test'],
                correctAnswer: 1,
                explanation: 'Intelligence tests measure cognitive abilities like reasoning, problem-solving, and memory.'
              },
              {
                id: '6',
                question: 'What is the Rorschach test?',
                options: ['IQ test', 'Projective test using inkblots', 'Achievement test', 'Personality inventory'],
                correctAnswer: 1,
                explanation: 'The Rorschach is a projective test where people interpret ambiguous inkblots.'
              },
              {
                id: '7',
                question: 'What is criterion validity?',
                options: ['Consistency', 'Test correlates with external measure', 'Internal structure', 'Face value'],
                correctAnswer: 1,
                explanation: 'Criterion validity is how well a test correlates with an external criterion or outcome.'
              },
              {
                id: '8',
                question: 'What is test-retest reliability?',
                options: ['Different testers', 'Same test given twice, similar scores', 'Internal consistency', 'Parallel forms'],
                correctAnswer: 1,
                explanation: 'Test-retest reliability assesses consistency by giving the same test twice to the same people.'
              },
              {
                id: '9',
                question: 'What is a percentile rank?',
                options: ['Raw score', 'Percentage of people scored below', 'Passing grade', 'Average'],
                correctAnswer: 1,
                explanation: 'A percentile rank indicates the percentage of people who scored below a given score.'
              },
              {
                id: '10',
                question: 'What is construct validity?',
                options: ['Surface appearance', 'Test measures the theoretical construct', 'Criterion relation', 'Reliability'],
                correctAnswer: 1,
                explanation: 'Construct validity is the degree to which a test measures the theoretical construct it\'s designed to measure.'
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: 'year4',
    name: 'Year 4',
    subjects: [
      {
        id: 'sensation-perception',
        name: 'Sensation and Perception',
        icon: 'brain',
        color: 'purple',
        topics: [
          {
            id: 'sensory-processes',
            name: 'Sensory Processes',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is the difference between sensation and perception?',
                options: ['Same thing', 'Sensation detects stimuli, perception interprets', 'Perception comes first', 'No difference'],
                correctAnswer: 1,
                explanation: 'Sensation is detecting physical stimuli; perception is interpreting and organizing those stimuli.'
              },
              {
                id: '2',
                question: 'What is the absolute threshold?',
                options: ['Maximum detection', 'Minimum stimulation needed to detect 50% of time', 'Average sensitivity', 'No threshold'],
                correctAnswer: 1,
                explanation: 'The absolute threshold is the minimum stimulation needed to detect a stimulus 50% of the time.'
              },
              {
                id: '3',
                question: 'What is Weber\'s Law?',
                options: ['Absolute threshold', 'Just noticeable difference is proportional to stimulus', 'Maximum sensation', 'No law'],
                correctAnswer: 1,
                explanation: 'Weber\'s Law states that the just noticeable difference is a constant proportion of the original stimulus.'
              },
              {
                id: '4',
                question: 'What is sensory adaptation?',
                options: ['Increased sensitivity', 'Decreased sensitivity to constant stimulus', 'Enhanced perception', 'No change'],
                correctAnswer: 1,
                explanation: 'Sensory adaptation is diminished sensitivity to a constant or unchanging stimulus.'
              },
              {
                id: '5',
                question: 'What is bottom-up processing?',
                options: ['Using expectations', 'Processing from sensory input', 'Top-down', 'No processing'],
                correctAnswer: 1,
                explanation: 'Bottom-up processing starts with sensory input and builds up to perception.'
              },
              {
                id: '6',
                question: 'What is top-down processing?',
                options: ['Sensory input only', 'Using knowledge and expectations to interpret', 'Bottom-up', 'No expectations'],
                correctAnswer: 1,
                explanation: 'Top-down processing uses prior knowledge and expectations to interpret sensory information.'
              },
              {
                id: '7',
                question: 'What is the blind spot?',
                options: ['Eye disease', 'Area where optic nerve exits, no photoreceptors', 'Blurry vision', 'Darkness'],
                correctAnswer: 1,
                explanation: 'The blind spot is the area where the optic nerve exits the eye, containing no photoreceptors.'
              },
              {
                id: '8',
                question: 'What are rods and cones?',
                options: ['Shapes', 'Photoreceptors for vision', 'Brain parts', 'Nerves'],
                correctAnswer: 1,
                explanation: 'Rods and cones are photoreceptor cells in the retina that detect light and enable vision.'
              },
              {
                id: '9',
                question: 'What is the trichromatic theory?',
                options: ['One color', 'Three types of color receptors', 'Four colors', 'No colors'],
                correctAnswer: 1,
                explanation: 'The trichromatic theory states that we have three types of color receptors (red, green, blue).'
              },
              {
                id: '10',
                question: 'What is the opponent-process theory?',
                options: ['One color', 'Colors organized in opposing pairs', 'Three colors', 'No organization'],
                correctAnswer: 1,
                explanation: 'The opponent-process theory proposes that colors are organized in opposing pairs (red-green, blue-yellow).'
              }
            ]
          }
        ]
      },
      {
        id: 'motivation-emotion',
        name: 'Motivation and Emotion',
        icon: 'heart',
        color: 'pink',
        topics: [
          {
            id: 'motivation-theories',
            name: 'Theories of Motivation',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is intrinsic motivation?',
                options: ['External rewards', 'Internal desire and enjoyment', 'Money', 'Punishment'],
                correctAnswer: 1,
                explanation: 'Intrinsic motivation comes from internal desire, interest, and enjoyment of the activity itself.'
              },
              {
                id: '2',
                question: 'What is extrinsic motivation?',
                options: ['Internal desire', 'External rewards or avoiding punishment', 'Enjoyment', 'Interest'],
                correctAnswer: 1,
                explanation: 'Extrinsic motivation comes from external rewards or avoiding punishment.'
              },
              {
                id: '3',
                question: 'What is Maslow\'s hierarchy of needs order?',
                options: ['Random', 'Physiological, Safety, Love, Esteem, Self-actualization', 'Reverse', 'Equal'],
                correctAnswer: 1,
                explanation: 'Maslow\'s hierarchy progresses from basic physiological needs to self-actualization.'
              },
              {
                id: '4',
                question: 'What is the Yerkes-Dodson law?',
                options: ['More arousal is better', 'Optimal performance at moderate arousal', 'Low arousal is best', 'No relationship'],
                correctAnswer: 1,
                explanation: 'The Yerkes-Dodson law states that performance is optimal at moderate levels of arousal.'
              },
              {
                id: '5',
                question: 'What is achievement motivation?',
                options: ['No goals', 'Desire to accomplish and excel', 'Avoiding tasks', 'Laziness'],
                correctAnswer: 1,
                explanation: 'Achievement motivation is the desire to accomplish goals and demonstrate competence.'
              },
              {
                id: '6',
                question: 'What is the James-Lange theory of emotion?',
                options: ['Emotion causes arousal', 'Physiological arousal causes emotion', 'Simultaneous', 'Cognition first'],
                correctAnswer: 1,
                explanation: 'The James-Lange theory proposes that physiological arousal causes emotional experience.'
              },
              {
                id: '7',
                question: 'What is the Cannon-Bard theory?',
                options: ['Sequential', 'Emotion and arousal occur simultaneously', 'Arousal first', 'Emotion first'],
                correctAnswer: 1,
                explanation: 'The Cannon-Bard theory states that emotion and physiological arousal occur simultaneously.'
              },
              {
                id: '8',
                question: 'What is the Schachter-Singer theory?',
                options: ['Arousal only', 'Arousal + cognitive label = emotion', 'Emotion only', 'No cognition'],
                correctAnswer: 1,
                explanation: 'The Schachter-Singer theory proposes that emotion results from physiological arousal plus cognitive labeling.'
              },
              {
                id: '9',
                question: 'What is emotional intelligence?',
                options: ['IQ', 'Ability to understand and manage emotions', 'Academic skills', 'Memory'],
                correctAnswer: 1,
                explanation: 'Emotional intelligence is the ability to perceive, understand, and manage emotions in self and others.'
              },
              {
                id: '10',
                question: 'What are basic emotions according to Ekman?',
                options: ['Complex only', 'Happiness, sadness, fear, anger, surprise, disgust', 'One emotion', 'No basic emotions'],
                correctAnswer: 1,
                explanation: 'Ekman identified six universal basic emotions: happiness, sadness, fear, anger, surprise, and disgust.'
              }
            ]
          }
        ]
      },
      {
        id: 'health-psych-y4',
        name: 'Health Psychology',
        icon: 'activity',
        color: 'green',
        topics: [
          {
            id: 'health-behavior',
            name: 'Health Behavior',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is the biopsychosocial model?',
                options: ['Biology only', 'Biological, psychological, and social factors integrated', 'Psychology only', 'Social only'],
                correctAnswer: 1,
                explanation: 'The biopsychosocial model integrates biological, psychological, and social factors in health.'
              },
              {
                id: '2',
                question: 'What is problem-focused coping?',
                options: ['Avoiding', 'Managing emotions', 'Taking action to change stressor', 'Support only'],
                correctAnswer: 2,
                explanation: 'Problem-focused coping involves taking direct action to change or eliminate stressors.'
              },
              {
                id: '3',
                question: 'What is emotion-focused coping?',
                options: ['Solving problem', 'Managing emotional response', 'Ignoring', 'Blaming'],
                correctAnswer: 1,
                explanation: 'Emotion-focused coping manages emotional reactions rather than changing the stressor.'
              },
              {
                id: '4',
                question: 'What is the health belief model?',
                options: ['Religious beliefs', 'Perceptions influencing health behaviors', 'Medical model', 'Diagnosis'],
                correctAnswer: 1,
                explanation: 'The health belief model explains how perceptions of threat and benefits influence health behaviors.'
              },
              {
                id: '5',
                question: 'What is self-efficacy?',
                options: ['Selfishness', 'Belief in ability to succeed', 'Low confidence', 'Arrogance'],
                correctAnswer: 1,
                explanation: 'Self-efficacy is one\'s belief in their ability to successfully perform specific behaviors.'
              },
              {
                id: '6',
                question: 'What is chronic stress?',
                options: ['Brief stress', 'Long-term ongoing stress', 'No stress', 'Positive stress'],
                correctAnswer: 1,
                explanation: 'Chronic stress is prolonged, ongoing stress that can harm physical and mental health.'
              },
              {
                id: '7',
                question: 'What is eustress?',
                options: ['Bad stress', 'Positive, motivating stress', 'No stress', 'Chronic stress'],
                correctAnswer: 1,
                explanation: 'Eustress is positive stress that can be motivating and beneficial.'
              },
              {
                id: '8',
                question: 'What is social support?',
                options: ['Being alone', 'Help and comfort from others', 'Financial only', 'Professional only'],
                correctAnswer: 1,
                explanation: 'Social support is the comfort, assistance, and information received from others.'
              },
              {
                id: '9',
                question: 'What is the General Adaptation Syndrome?',
                options: ['One stage', 'Three stages: Alarm, Resistance, Exhaustion', 'No adaptation', 'Five stages'],
                correctAnswer: 1,
                explanation: 'GAS describes three stages of stress response: alarm, resistance, and exhaustion.'
              },
              {
                id: '10',
                question: 'What is resilience?',
                options: ['Avoiding stress', 'Ability to bounce back from adversity', 'Never facing hardship', 'Ignoring problems'],
                correctAnswer: 1,
                explanation: 'Resilience is the ability to adapt and recover from stress, adversity, or trauma.'
              }
            ]
          }
        ]
      },
      {
        id: 'criminal-psych',
        name: 'Criminal Psychology',
        icon: 'users',
        color: 'red',
        topics: [
          {
            id: 'criminal-behavior',
            name: 'Criminal Behavior',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is forensic psychology?',
                options: ['Crime scene analysis', 'Application of psychology to legal/criminal justice', 'Police work', 'Lab science'],
                correctAnswer: 1,
                explanation: 'Forensic psychology applies psychological principles to legal and criminal justice systems.'
              },
              {
                id: '2',
                question: 'What is psychopathy?',
                options: ['Psychosis', 'Personality disorder with lack of empathy and antisocial behavior', 'Mental illness', 'Depression'],
                correctAnswer: 1,
                explanation: 'Psychopathy is characterized by lack of empathy, manipulativeness, and persistent antisocial behavior.'
              },
              {
                id: '3',
                question: 'What is competency to stand trial?',
                options: ['Guilt', 'Understanding charges and assisting in defense', 'Innocence', 'Sentencing'],
                correctAnswer: 1,
                explanation: 'Competency to stand trial means understanding charges and being able to assist in one\'s defense.'
              },
              {
                id: '4',
                question: 'What is the insanity defense?',
                options: ['Guilty', 'Not responsible due to mental illness at time of offense', 'Innocent', 'Plea bargain'],
                correctAnswer: 1,
                explanation: 'The insanity defense claims the defendant was not criminally responsible due to mental illness.'
              },
              {
                id: '5',
                question: 'What is criminal profiling?',
                options: ['Photography', 'Analyzing crime to infer offender characteristics', 'DNA testing', 'Fingerprinting'],
                correctAnswer: 1,
                explanation: 'Criminal profiling analyzes crime scene evidence to infer characteristics of the offender.'
              },
              {
                id: '6',
                question: 'What is recidivism?',
                options: ['First offense', 'Reoffending after punishment', 'Rehabilitation', 'Innocence'],
                correctAnswer: 1,
                explanation: 'Recidivism is the tendency to reoffend after being punished or treated for criminal behavior.'
              },
              {
                id: '7',
                question: 'What is antisocial personality disorder?',
                options: ['Shyness', 'Persistent disregard for rights of others', 'Anxiety', 'Depression'],
                correctAnswer: 1,
                explanation: 'Antisocial personality disorder involves persistent disregard for and violation of others\' rights.'
              },
              {
                id: '8',
                question: 'What is risk assessment in forensic psychology?',
                options: ['Guilt determination', 'Evaluating likelihood of future violence', 'Sentencing', 'Diagnosis'],
                correctAnswer: 1,
                explanation: 'Risk assessment evaluates the likelihood that an individual will engage in future violent behavior.'
              },
              {
                id: '9',
                question: 'What is malingering?',
                options: ['True illness', 'Faking mental illness for gain', 'Recovery', 'Treatment'],
                correctAnswer: 1,
                explanation: 'Malingering is intentionally faking or exaggerating mental illness for external benefits.'
              },
              {
                id: '10',
                question: 'What is restorative justice?',
                options: ['Punishment only', 'Repairing harm and accountability', 'Imprisonment', 'Fines'],
                correctAnswer: 1,
                explanation: 'Restorative justice focuses on repairing harm, accountability, and involving victims in the process.'
              }
            ]
          }
        ]
      },
      {
        id: 'user-psych',
        name: 'User Psychology',
        icon: 'users',
        color: 'blue',
        topics: [
          {
            id: 'user-experience',
            name: 'User Experience',
            completed: false,
            questions: [
              {
                id: '1',
                question: 'What is user experience (UX)?',
                options: ['Design only', 'Overall experience interacting with product', 'Appearance only', 'Technology'],
                correctAnswer: 1,
                explanation: 'User experience encompasses all aspects of a person\'s interaction with a product or service.'
              },
              {
                id: '2',
                question: 'What is cognitive load?',
                options: ['Physical weight', 'Mental effort required to process information', 'Emotional burden', 'Social pressure'],
                correctAnswer: 1,
                explanation: 'Cognitive load is the amount of mental effort required to process and understand information.'
              },
              {
                id: '3',
                question: 'What is affordance in design?',
                options: ['Cost', 'Properties suggesting how to use object', 'Appearance', 'Material'],
                correctAnswer: 1,
                explanation: 'Affordance refers to properties of an object that suggest how it should be used.'
              },
              {
                id: '4',
                question: 'What is the principle of least effort?',
                options: ['Work hard', 'People choose path requiring least effort', 'Maximum effort', 'No effort'],
                correctAnswer: 1,
                explanation: 'The principle of least effort states that people will choose the path requiring minimal effort.'
              },
              {
                id: '5',
                question: 'What is mental model?',
                options: ['Physical model', 'User\'s understanding of how system works', 'Designer\'s plan', 'Actual system'],
                correctAnswer: 1,
                explanation: 'A mental model is a user\'s internal representation of how a system works.'
              },
              {
                id: '6',
                question: 'What is usability?',
                options: ['Appearance', 'Ease of use and learnability', 'Popularity', 'Price'],
                correctAnswer: 1,
                explanation: 'Usability refers to how easy and intuitive a product is to use and learn.'
              },
              {
                id: '7',
                question: 'What is the Fitts\'s Law?',
                options: ['Random', 'Time to reach target depends on distance and size', 'No relationship', 'Color theory'],
                correctAnswer: 1,
                explanation: 'Fitts\'s Law states that time to reach a target is related to its distance and size.'
              },
              {
                id: '8',
                question: 'What is the Hick\'s Law?',
                options: ['Fewer choices slower', 'More choices increase decision time', 'No effect', 'Same time'],
                correctAnswer: 1,
                explanation: 'Hick\'s Law states that increasing the number of choices increases decision time.'
              },
              {
                id: '9',
                question: 'What is user-centered design?',
                options: ['Designer focused', 'Designing with user needs central', 'Technology focused', 'Business focused'],
                correctAnswer: 1,
                explanation: 'User-centered design places user needs, wants, and limitations at the center of design process.'
              },
              {
                id: '10',
                question: 'What is accessibility in design?',
                options: ['Location', 'Usable by people with diverse abilities', 'Availability', 'Price'],
                correctAnswer: 1,
                explanation: 'Accessibility ensures products can be used by people with diverse abilities and disabilities.'
              }
            ]
          }
        ]
      }
    ]
  }
];
