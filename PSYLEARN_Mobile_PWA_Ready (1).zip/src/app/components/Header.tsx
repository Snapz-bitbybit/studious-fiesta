import { Flame, Award, BookOpen, FileText } from 'lucide-react';
import logo from "figma:asset/daabe322baca76a4bfd50f56360517223f21f9cf.png";

interface HeaderProps {
  onOpenNotes: () => void;
  onOpenJournal: () => void;
}

export function Header({ onOpenNotes, onOpenJournal }: HeaderProps) {
  return (
    <header className="bg-white shadow-md border-b-4 border-gradient-to-r from-purple-400 to-pink-400">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white rounded-2xl shadow-lg transform hover:scale-110 transition-transform overflow-hidden w-12 h-12">
              <img src={logo} alt="PSYLEARN Logo" className="w-full h-full object-cover" />
            </div>
            <div>
              <h1 className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">PSYLEARN</h1>
              <p className="text-sm bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">Master Psychology</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={onOpenNotes}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-400 to-cyan-400 text-white rounded-xl hover:shadow-lg transition-all hover:scale-105 transform"
            >
              <BookOpen className="w-5 h-5" />
              <span className="hidden sm:inline">Notes</span>
            </button>
            <button
              onClick={onOpenJournal}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-400 to-fuchsia-400 text-white rounded-xl hover:shadow-lg transition-all hover:scale-105 transform"
            >
              <FileText className="w-5 h-5" />
              <span className="hidden sm:inline">Journal</span>
            </button>
            <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-orange-400 to-red-400 text-white rounded-xl shadow-md">
              <Flame className="w-5 h-5" />
              <span className="hidden sm:inline">7 days</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-yellow-400 to-orange-400 text-white rounded-xl shadow-md">
              <Award className="w-5 h-5" />
              <span>240 XP</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}