import { useState } from 'react';
import { ArrowLeft, BookOpen, Search, ChevronDown, ChevronRight } from 'lucide-react';

interface NotesProps {
  onBack: () => void;
}

interface NoteContent {
  id: string;
  subject: string;
  year: string;
  color: string;
  sections: {
    title: string;
    content: string;
  }[];
}

const psychologyNotes: NoteContent[] = [
  {
    id: 'intro-cog-sci',
    subject: 'Introduction to Cognitive Sciences',
    year: 'Year 1',
    color: 'purple',
    sections: [
      {
        title: 'What is Cognitive Science?',
        content: 'Cognitive science is the interdisciplinary study of mind and intelligence, embracing philosophy, psychology, artificial intelligence, neuroscience, linguistics, and anthropology. It seeks to understand the principles of intelligence and how the mind represents and processes information.'
      },
      {
        title: 'Key Concepts',
        content: '• Information Processing: The mind as a computational system\n• Representation: How knowledge is stored and organized\n• Cognitive Architecture: The structure of mental processes\n• Embodied Cognition: The role of the body in thinking'
      },
      {
        title: 'Research Methods',
        content: 'Cognitive scientists use behavioral experiments, brain imaging (fMRI, EEG), computational modeling, and linguistic analysis to study mental processes. Methods include reaction time studies, eye tracking, and protocol analysis.'
      }
    ]
  },
  {
    id: 'cognitive-psych',
    subject: 'Cognitive Psychology',
    year: 'Year 1',
    color: 'purple',
    sections: [
      {
        title: 'Memory Systems',
        content: '• Sensory Memory: Brief storage (< 1 second)\n• Short-Term Memory: 7±2 items, 15-30 seconds\n• Long-Term Memory: Unlimited capacity, permanent storage\n• Working Memory: Active manipulation of information (Baddeley\'s model: phonological loop, visuospatial sketchpad, central executive, episodic buffer)'
      },
      {
        title: 'Attention',
        content: 'Selective Attention: Focusing on specific stimuli (Cherry\'s dichotic listening, Stroop effect)\nDivided Attention: Processing multiple stimuli simultaneously\nSustained Attention: Maintaining focus over time\nKey theories: Broadbent\'s filter model, Treisman\'s attenuation theory'
      },
      {
        title: 'Problem Solving & Decision Making',
        content: 'Problem-solving strategies: Algorithms (step-by-step), Heuristics (mental shortcuts)\nCommon heuristics: Availability, Representativeness, Anchoring\nBiases: Confirmation bias, Functional fixedness, Mental set\nDecision-making models: Expected utility theory, Prospect theory'
      }
    ]
  },
  {
    id: 'intro-psychology',
    subject: 'Introduction to Psychology',
    year: 'Year 1',
    color: 'blue',
    sections: [
      {
        title: 'Major Perspectives',
        content: '• Biological: Brain, genetics, neurotransmitters\n• Behavioral: Observable behavior, learning, conditioning\n• Cognitive: Mental processes, thinking, memory\n• Psychodynamic: Unconscious mind, childhood experiences\n• Humanistic: Personal growth, self-actualization\n• Sociocultural: Culture, society, context'
      },
      {
        title: 'Research Methods',
        content: 'Experimental: Manipulate IV, measure DV, establish causation\nCorrelational: Examine relationships between variables\nDescriptive: Surveys, case studies, naturalistic observation\nKey concepts: Random assignment, control groups, validity, reliability'
      },
      {
        title: 'History of Psychology',
        content: 'Founders: Wilhelm Wundt (1879, first lab), William James (functionalism), Sigmund Freud (psychoanalysis)\nSchools: Structuralism, Functionalism, Behaviorism, Gestalt, Humanistic\nModern psychology: Cognitive revolution (1950s-60s), neuroscience integration'
      }
    ]
  },
  {
    id: 'developmental-psych',
    subject: 'Developmental Psychology',
    year: 'Year 1',
    color: 'green',
    sections: [
      {
        title: 'Piaget\'s Stages',
        content: '1. Sensorimotor (0-2 years): Object permanence, goal-directed behavior\n2. Preoperational (2-7 years): Symbolic thinking, egocentrism, lack of conservation\n3. Concrete Operational (7-11 years): Logical thinking, conservation, reversibility\n4. Formal Operational (11+ years): Abstract reasoning, hypothetical thinking'
      },
      {
        title: 'Attachment Theory (Bowlby & Ainsworth)',
        content: 'Secure: Comfortable exploring, upset when separated, happy when reunited\nInsecure-Avoidant: Little distress at separation, avoids caregiver\nInsecure-Resistant: Very distressed at separation, ambivalent when reunited\nDisorganized: Inconsistent, confused behavior\nStrange Situation: Laboratory procedure to assess attachment'
      },
      {
        title: 'Erikson\'s Psychosocial Stages',
        content: 'Trust vs. Mistrust (0-1): Can I trust the world?\nAutonomy vs. Shame (1-3): Can I do things myself?\nInitiative vs. Guilt (3-6): Am I good or bad?\nIndustry vs. Inferiority (6-12): Am I competent?\nIdentity vs. Role Confusion (12-18): Who am I?\nIntimacy vs. Isolation (Young adult)\nGenerativity vs. Stagnation (Middle age)\nIntegrity vs. Despair (Late adult)'
      }
    ]
  },
  {
    id: 'social-psych',
    subject: 'Social Psychology',
    year: 'Year 1',
    color: 'pink',
    sections: [
      {
        title: 'Social Influence',
        content: 'Conformity: Asch line studies (75% conformed at least once)\nObedience: Milgram experiments (65% went to maximum shock)\nCompliance: Foot-in-door, Door-in-face, Low-ball techniques\nNormative influence: Desire to be liked\nInformational influence: Desire to be correct'
      },
      {
        title: 'Attitudes & Persuasion',
        content: 'Attitude components: Cognitive (beliefs), Affective (feelings), Behavioral (actions)\nCognitive Dissonance: Discomfort from conflicting cognitions (Festinger)\nPersuasion routes: Central (logical arguments), Peripheral (superficial cues)\nFactors: Source credibility, message quality, audience characteristics'
      },
      {
        title: 'Group Dynamics',
        content: 'Social Facilitation: Better performance on simple tasks with audience\nSocial Loafing: Reduced effort in groups\nGroupthink: Poor decisions due to desire for harmony\nDeindividuation: Loss of self-awareness in groups\nBystander Effect: Less likely to help when others present (Kitty Genovese case)'
      }
    ]
  },
  {
    id: 'group-dynamics-comprehensive',
    subject: 'Group Dynamics (Comprehensive)',
    year: 'Year 3',
    color: 'green',
    sections: [
      {
        title: 'Chapter 2: Scientific Study of Groups',
        content: 'Overview: Introduces research methodologies and theoretical frameworks used to study group processes scientifically. Covers experimental designs, observational methods, measurement techniques, and ethical considerations in group research.\n\nKey Topics:\n• Research Methods: Case studies, correlational studies, experimental designs, field research\n• Measurement: Sociometry, interaction analysis, self-report measures, behavioral observations\n• Theoretical Perspectives: Social identity theory, social exchange theory, systems theory\n• Levels of Analysis: Individual, interpersonal, group, organizational\n• Validity & Reliability: Internal/external validity, ecological validity, measurement reliability\n• Meta-analysis and research synthesis in group dynamics'
      },
      {
        title: 'Chapter 3: Inclusion, Identity, and Formation',
        content: 'Overview: Examines how groups form, who joins groups, and how group membership shapes personal identity. Explores motivations for group membership, socialization processes, and identity development within groups.\n\nKey Topics:\n• Need to Belong: Evolutionary basis, Baumeister & Leary\'s belongingness hypothesis\n• Social Identity Theory: Tajfel & Turner - ingroup favoritism, social categorization, self-esteem\n• Group Formation: Proximity, similarity, complementarity, reciprocity\n• Group Socialization: Moreland & Levine\'s model - investigation, socialization, maintenance, resocialization, remembrance\n• Personal vs. Social Identity: Self-categorization theory (Turner)\n• Inclusionary Status: Acceptance, ambivalence, rejection, marginalization'
      },
      {
        title: 'Chapter 4: Cohesion and Development',
        content: 'Overview: Analyzes the forces that bind group members together (cohesion) and the stages groups pass through over time (development). Critical for understanding group stability and effectiveness.\n\nKey Topics:\n• Group Cohesion: Definition, antecedents, consequences; task vs. social cohesion\n• Measuring Cohesion: Sociometric methods, GEQ (Group Environment Questionnaire)\n• Stages of Development: Tuckman\'s model - forming, storming, norming, performing, adjourning\n• Punctuated Equilibrium Model: Gersick\'s theory of developmental transitions\n• Factors Affecting Cohesion: Group size, similarity, success, external threats\n• Consequences: Performance, satisfaction, conformity pressure\n• Dissolution and Termination: Reasons groups end, emotional responses'
      },
      {
        title: 'Chapter 5: Group Structure',
        content: 'Overview: Explores the underlying organizational patterns that characterize groups, including roles, norms, and status hierarchies. Essential for understanding how groups organize themselves.\n\nKey Topics:\n• Roles: Role differentiation, task vs. socioemotional roles, Bales\' IPA, role conflict/ambiguity\n• Norms: Development, types (descriptive/injunctive), enforcement, Sherif\'s autokinetic effect\n• Status: Status characteristics theory (Berger), status hierarchies, pecking orders\n• Communication Networks: Centralized vs. decentralized, Bavelas\' research, communication patterns\n• Spatial Arrangements: Personal space, territoriality, seating patterns, Sommer\'s findings\n• Intermember Relations: Attraction patterns, sociometric structures, cliques and coalitions'
      },
      {
        title: 'Chapter 6: Influence',
        content: 'Overview: Examines social influence processes including conformity, compliance, and obedience. Investigates how group members change attitudes and behaviors in response to others.\n\nKey Topics:\n• Conformity: Asch\'s line studies, majority influence, informational vs. normative influence\n• Minority Influence: Moscovici\'s research, consistency, conversion theory\n• Compliance: Foot-in-the-door, door-in-the-face, that\'s-not-all, low-ball technique\n• Obedience: Milgram\'s experiments, factors affecting obedience, ethical implications\n• Social Impact Theory: Latané - strength, immediacy, number of sources\n• Power Bases: French & Raven - reward, coercive, legitimate, referent, expert, informational\n• Resistance to Influence: Reactance theory, inoculation'
      },
      {
        title: 'Chapter 7: Leadership',
        content: 'Overview: Investigates leadership emergence, styles, and effectiveness in groups. Covers classic and contemporary theories of leadership and their empirical support.\n\nKey Topics:\n• Trait Approaches: Big Five personality traits, intelligence, emotional intelligence\n• Behavioral Theories: Ohio State studies (consideration/initiating structure), Blake & Mouton grid\n• Contingency Theories: Fiedler\'s model, situational favorability, LPC scale\n• Situational Leadership: Hersey & Blanchard - directive, coaching, supporting, delegating\n• Transformational vs. Transactional: Bass - idealized influence, inspirational motivation, intellectual stimulation, individualized consideration\n• Leader-Member Exchange (LMX): In-group vs. out-group relationships\n• Authentic, Servant, Ethical Leadership: Contemporary approaches'
      },
      {
        title: 'Chapter 8: Group Performance',
        content: 'Overview: Analyzes factors that enhance or impair group productivity and performance. Examines when groups outperform individuals and vice versa.\n\nKey Topics:\n• Social Facilitation: Zajonc\'s drive theory, mere presence, evaluation apprehension\n• Social Loafing: Latané - reduced effort, identifiability, dispensability, causes and remedies\n• Process Loss vs. Gain: Steiner\'s typology - actual vs. potential productivity\n• Task Types: Additive, conjunctive, disjunctive, divisible tasks\n• Brainstorming: Production blocking, evaluation apprehension, effectiveness\n• Synergy: Collective intelligence, wisdom of crowds, conditions for emergence\n• Motivation Losses: Free-riding, sucker effect\n• Coordination Problems: Ringelmann effect'
      },
      {
        title: 'Chapter 9: Teams',
        content: 'Overview: Distinguishes teams from general groups and examines what makes teams effective. Focuses on team composition, processes, and performance in organizational contexts.\n\nKey Topics:\n• Team Definition: High interdependence, shared goals, structural properties\n• Team Composition: Diversity, skills, personality, size optimization\n• Team Development: Building shared mental models, transactive memory systems\n• Team Processes: Coordination, cooperation, communication, backup behavior\n• Virtual Teams: Technology-mediated collaboration, challenges, best practices\n• Team Effectiveness Models: Input-Process-Outcome (IPO), IMOI models\n• High-Performance Teams: Characteristics, psychological safety, trust\n• Team Training: Crew resource management, team-building interventions'
      },
      {
        title: 'Chapter 10: Group Decision Making',
        content: 'Overview: Examines how groups make decisions, including both strengths and weaknesses of group judgment. Critical examination of groupthink and decision-making biases.\n\nKey Topics:\n• Group vs. Individual Decisions: When groups excel, when individuals are better\n• Information Sharing: Common knowledge effect, hidden profiles, Stasser\'s research\n• Groupthink: Janis\' theory - symptoms, antecedents, preventive measures, historical examples\n• Group Polarization: Risky/cautious shift, social comparison, persuasive arguments theory\n• Decision Rules: Majority, plurality, unanimity, consensus\n• Discussion Processes: Participation rates, biased sampling, confirmation bias\n• Improving Decisions: Devil\'s advocate, dialectical inquiry, Delphi technique, nominal group technique\n• Collective Intelligence: Conditions for superior group judgment'
      },
      {
        title: 'Chapter 11: Conflict',
        content: 'Overview: Analyzes the nature, causes, and resolution of intergroup and intragroup conflict. Examines both constructive and destructive aspects of group conflict.\n\nKey Topics:\n• Types of Conflict: Task, relationship, process conflict; Jehn\'s research\n• Sources of Conflict: Scarcity, misunderstanding, differences in goals/values, interdependence\n• Conflict Escalation: Deutsch\'s competitive vs. cooperative processes, spiral model\n• Intergroup Conflict: Realistic conflict theory (Sherif), social identity approaches\n• Conflict Styles: Thomas-Kilmann model - competing, collaborating, compromising, avoiding, accommodating\n• Negotiation: Distributive vs. integrative, BATNA, anchoring, framing\n• Mediation and Third-Party Intervention: Mediator roles, effectiveness\n• Resolution Strategies: Superordinate goals, contact hypothesis (Allport), jigsaw classroom'
      }
    ]
  },
  {
    id: 'abnormal-psych',
    subject: 'Abnormal Psychology',
    year: 'Year 2',
    color: 'red',
    sections: [
      {
        title: 'Anxiety Disorders',
        content: 'Generalized Anxiety Disorder (GAD): Excessive worry about multiple concerns\nPanic Disorder: Recurrent unexpected panic attacks\nSpecific Phobias: Irrational fear of specific objects/situations\nSocial Anxiety: Fear of social/performance situations\nAgoraphobia: Fear of situations where escape is difficult\nTreatment: CBT (most effective), SSRIs, exposure therapy'
      },
      {
        title: 'Mood Disorders',
        content: 'Major Depressive Disorder: Persistent low mood, loss of interest (≥2 weeks)\nSymptoms: Sleep changes, appetite changes, fatigue, worthlessness, suicidal ideation\nBipolar Disorder: Alternating manic and depressive episodes\nMania: Elevated mood, increased energy, decreased sleep, risky behavior\nTreatment: Antidepressants (SSRIs), mood stabilizers (lithium), psychotherapy'
      },
      {
        title: 'Schizophrenia Spectrum',
        content: 'Positive symptoms: Hallucinations, delusions, disorganized speech\nNegative symptoms: Flat affect, avolition, alogia, anhedonia\nCognitive symptoms: Impaired attention, memory, executive function\nDopamine hypothesis: Excess dopamine activity in certain brain regions\nTreatment: Antipsychotics (typical and atypical), psychosocial interventions'
      }
    ]
  },
  {
    id: 'counselling-psych',
    subject: 'Counselling Psychology',
    year: 'Year 2',
    color: 'purple',
    sections: [
      {
        title: 'Core Counselling Skills',
        content: 'Active Listening: Full attention, reflection, paraphrasing\nEmpathy: Understanding client\'s emotional experience\nGenuineness: Authentic, congruent presentation\nUnconditional Positive Regard: Acceptance without judgment\nOpen-ended questions: Encourage exploration\nSummarization: Condensing key themes\nImmediacy: Addressing here-and-now relationship'
      },
      {
        title: 'Therapeutic Approaches',
        content: 'Person-Centered (Rogers): Client-led, non-directive, focus on self-actualization\nCognitive-Behavioral (CBT): Change thoughts to change feelings and behaviors\nPsychodynamic: Explore unconscious conflicts and past experiences\nSolution-Focused: Goal-oriented, future-focused, identify exceptions\nNarrative Therapy: Re-authoring personal stories'
      },
      {
        title: 'Stages of Counselling',
        content: '1. Relationship Building: Establish rapport, trust, safety\n2. Assessment: Understand presenting issues, history, strengths\n3. Goal Setting: Collaborative, specific, measurable objectives\n4. Intervention: Apply techniques, explore issues, facilitate change\n5. Termination: Review progress, prevent relapse, closure'
      }
    ]
  },
  {
    id: 'personality',
    subject: 'Personality and Individual Differences',
    year: 'Year 2',
    color: 'orange',
    sections: [
      {
        title: 'Big Five Personality Traits (OCEAN)',
        content: 'Openness: Imagination, creativity, curiosity\nConscientiousness: Organization, discipline, goal-directed\nExtraversion: Sociability, energy, positive emotions\nAgreeableness: Cooperation, compassion, trust\nNeuroticism: Emotional instability, anxiety, moodiness\nHighly heritable (~50%) and stable across lifespan'
      },
      {
        title: 'Psychodynamic Theory (Freud)',
        content: 'Id: Pleasure principle, unconscious urges\nEgo: Reality principle, mediates between id and superego\nSuperego: Moral conscience, internalized standards\nDefense Mechanisms: Repression, denial, projection, displacement, sublimation\nPsychosexual Stages: Oral, Anal, Phallic, Latency, Genital'
      },
      {
        title: 'Humanistic Theories',
        content: 'Maslow\'s Hierarchy: Physiological, Safety, Love/Belonging, Esteem, Self-Actualization\nRogers\' Self Theory: Real self vs. Ideal self, conditions of worth\nSelf-actualization: Realizing full potential, peak experiences\nFocus on free will, personal growth, subjective experience'
      }
    ]
  },
  {
    id: 'clinical-psych',
    subject: 'Clinical Psychology',
    year: 'Year 3',
    color: 'red',
    sections: [
      {
        title: 'Assessment & Diagnosis',
        content: 'Clinical Interview: Structured, semi-structured, unstructured\nPsychological Testing: MMPI, Rorschach, TAT, IQ tests\nBehavioral Observation: Functional analysis, ABC model\nDSM-5: Diagnostic and Statistical Manual (classification system)\nDifferential Diagnosis: Ruling out alternative explanations\nComorbidity: Multiple concurrent disorders'
      },
      {
        title: 'Evidence-Based Treatments',
        content: 'Cognitive-Behavioral Therapy: Anxiety, depression, PTSD (highest efficacy)\nDialectical Behavior Therapy: Borderline personality disorder, emotion regulation\nExposure Therapy: Phobias, OCD, PTSD\nAcceptance and Commitment Therapy: Psychological flexibility, values-based action\nInterpersonal Therapy: Depression, relationship issues'
      },
      {
        title: 'Ethical Practice',
        content: 'Confidentiality: Limits (harm to self/others, child abuse, court order)\nInformed Consent: Voluntary, understanding risks/benefits\nCompetence: Practice within training and expertise\nDual Relationships: Avoid conflicts of interest\nCultural Sensitivity: Respect diversity, avoid bias'
      }
    ]
  },
  {
    id: 'io-psych',
    subject: 'Industrial/Organisational Psychology',
    year: 'Year 3',
    color: 'blue',
    sections: [
      {
        title: 'Personnel Selection',
        content: 'Job Analysis: Identify KSAOs (Knowledge, Skills, Abilities, Other)\nRecruitment: Internal vs. external, realistic job previews\nSelection Methods: Interviews, tests, assessment centers, work samples\nReliability & Validity: Consistency and accuracy of measures\nStructured Interviews: Standardized questions, behavioral/situational'
      },
      {
        title: 'Motivation Theories',
        content: 'Maslow\'s Hierarchy: Basic needs to self-actualization\nHerzberg\'s Two-Factor: Hygiene factors (prevent dissatisfaction) vs. Motivators (create satisfaction)\nExpectancy Theory: Effort → Performance → Outcome, based on expectancy, instrumentality, valence\nGoal-Setting Theory: Specific, difficult goals enhance performance\nEquity Theory: Fairness of input/output ratios'
      },
      {
        title: 'Leadership',
        content: 'Trait Approach: Intelligence, confidence, determination\nBehavioral Theories: Task-oriented vs. relationship-oriented\nContingency Theories: Match leadership style to situation\nTransformational Leadership: Inspire, motivate, intellectual stimulation\nTransactional Leadership: Rewards and punishments for performance'
      }
    ]
  },
  {
    id: 'experimental-psych',
    subject: 'Experimental Psychology',
    year: 'Year 3',
    color: 'indigo',
    sections: [
      {
        title: 'Experimental Design',
        content: 'Independent Variable: Manipulated by researcher\nDependent Variable: Measured outcome\nControl Variables: Held constant\nRandom Assignment: Eliminates selection bias\nBetween-subjects: Different participants per condition\nWithin-subjects: Same participants in all conditions\nMixed Design: Combination of between and within'
      },
      {
        title: 'Validity & Reliability',
        content: 'Internal Validity: Can we establish causation?\nExternal Validity: Can we generalize results?\nConstruct Validity: Are we measuring what we intend?\nReliability: Consistency of measurements\nThreats: Confounds, demand characteristics, experimenter bias\nCounterbalancing: Control for order effects'
      },
      {
        title: 'Statistical Analysis',
        content: 'Descriptive Statistics: Mean, median, mode, SD\nInferential Statistics: Generalize from sample to population\nt-test: Compare two means\nANOVA: Compare multiple means\nCorrelation: Relationship between variables (r = -1 to +1)\nRegression: Predict outcomes\np-value: Probability results due to chance (p < .05 = significant)'
      }
    ]
  },
  {
    id: 'health-psych',
    subject: 'Health Psychology',
    year: 'Year 4',
    color: 'green',
    sections: [
      {
        title: 'Stress & Coping',
        content: 'General Adaptation Syndrome (Selye): Alarm, Resistance, Exhaustion\nTypes: Acute vs. Chronic stress, Eustress vs. Distress\nProblem-focused coping: Change the stressor\nEmotion-focused coping: Manage emotional response\nSocial support: Emotional, instrumental, informational\nStress management: Relaxation, exercise, time management, mindfulness'
      },
      {
        title: 'Health Behavior Change',
        content: 'Health Belief Model: Perceived susceptibility, severity, benefits, barriers, cues to action\nTheory of Planned Behavior: Attitudes, subjective norms, perceived control → Intention → Behavior\nTranstheoretical Model (Stages of Change): Precontemplation, Contemplation, Preparation, Action, Maintenance\nSelf-efficacy: Belief in ability to succeed (Bandura)'
      },
      {
        title: 'Biopsychosocial Model',
        content: 'Biological: Genetics, physiology, illness\nPsychological: Thoughts, emotions, behaviors, stress\nSocial: Relationships, culture, socioeconomic status\nIntegrated approach to understanding health and illness\nHolistic treatment: Address all three domains'
      }
    ]
  },
  {
    id: 'criminal-psych',
    subject: 'Criminal Psychology',
    year: 'Year 4',
    color: 'red',
    sections: [
      {
        title: 'Theories of Criminal Behavior',
        content: 'Biological: Genetics, brain abnormalities, neurotransmitters (low serotonin)\nPsychological: Personality disorders (psychopathy, antisocial PD), cognitive distortions\nSocial Learning: Modeling, reinforcement of criminal behavior\nStrain Theory: Crime as response to blocked opportunities\nLabeling Theory: Criminal identity from societal reaction'
      },
      {
        title: 'Forensic Assessment',
        content: 'Competency to Stand Trial: Understand charges, assist in defense\nCriminal Responsibility: Mental state at time of offense (insanity defense)\nRisk Assessment: Likelihood of future violence (actuarial vs. clinical)\nPsychopathy Checklist (PCL-R): Hare\'s assessment of psychopathic traits\nMalingering Detection: Feigning mental illness'
      },
      {
        title: 'Offender Rehabilitation',
        content: 'Risk-Need-Responsivity Model: Target criminogenic needs, match to learning style\nCognitive-Behavioral Interventions: Change thinking patterns, moral reasoning\nSubstance Abuse Treatment: Address underlying addiction\nRecidivism Prevention: Relapse prevention strategies\nRestorative Justice: Repair harm, accountability, victim involvement'
      }
    ]
  }
];

const colorClasses = {
  purple: 'from-purple-400 to-fuchsia-400',
  blue: 'from-blue-400 to-cyan-400',
  green: 'from-green-400 to-emerald-400',
  red: 'from-red-400 to-pink-400',
  orange: 'from-orange-400 to-amber-400',
  indigo: 'from-indigo-400 to-purple-400',
  pink: 'from-pink-400 to-rose-400'
};

export function Notes({ onBack }: NotesProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedYear, setSelectedYear] = useState('All');
  const [expandedNote, setExpandedNote] = useState<string | null>(null);

  const years = ['All', 'Year 1', 'Year 2', 'Year 3', 'Year 4'];

  const filteredNotes = psychologyNotes.filter(note => {
    const matchesSearch = note.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         note.sections.some(section => 
                           section.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           section.content.toLowerCase().includes(searchQuery.toLowerCase())
                         );
    const matchesYear = selectedYear === 'All' || note.year === selectedYear;
    return matchesSearch && matchesYear;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white shadow-md border-b-4 border-gradient-to-r from-purple-400 to-pink-400">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </button>
            <div className="flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-purple-600" />
              <h1 className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">Psychology Study Notes</h1>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8 text-center">
          <p className="text-gray-600">
            Comprehensive study notes for all psychology subjects
          </p>
        </div>

        {/* Search and Filter */}
        <div className="mb-8 flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search subjects or topics..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(e.target.value)}
            className="px-4 py-3 bg-white border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            {years.map((year) => (
              <option key={year} value={year}>
                {year}
              </option>
            ))}
          </select>
        </div>

        {/* Notes List */}
        {filteredNotes.length === 0 ? (
          <div className="text-center py-16">
            <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No notes found matching your search.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredNotes.map((note) => (
              <div
                key={note.id}
                className="bg-white rounded-3xl shadow-lg hover:shadow-xl transition-all overflow-hidden border-2 border-gray-100"
              >
                <button
                  onClick={() => setExpandedNote(expandedNote === note.id ? null : note.id)}
                  className={`w-full p-6 bg-gradient-to-r ${colorClasses[note.color as keyof typeof colorClasses]} text-white transition-all`}
                >
                  <div className="flex items-center justify-between">
                    <div className="text-left">
                      <h3 className="text-white drop-shadow-md mb-1">{note.subject}</h3>
                      <p className="text-sm text-white/90">{note.year} • {note.sections.length} sections</p>
                    </div>
                    {expandedNote === note.id ? (
                      <ChevronDown className="w-7 h-7" />
                    ) : (
                      <ChevronRight className="w-7 h-7" />
                    )}
                  </div>
                </button>

                {expandedNote === note.id && (
                  <div className="p-8 space-y-6 bg-gradient-to-br from-gray-50 to-white">
                    {note.sections.map((section, index) => (
                      <div key={index} className="border-l-4 border-purple-300 pl-6">
                        <h4 className="text-gray-800 mb-3">{section.title}</h4>
                        <p className="text-gray-700 whitespace-pre-line leading-relaxed">
                          {section.content}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}