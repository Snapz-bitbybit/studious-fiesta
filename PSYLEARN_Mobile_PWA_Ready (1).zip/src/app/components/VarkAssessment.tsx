import { useState } from 'react';
import { ArrowLeft, Eye, Ear, Hand, BookOpen, CheckCircle } from 'lucide-react';

interface VarkAssessmentProps {
  onBack: () => void;
}

interface Question {
  id: number;
  question: string;
  options: {
    text: string;
    type: 'V' | 'A' | 'R' | 'K';
  }[];
}

const varkQuestions: Question[] = [
  {
    id: 1,
    question: 'When learning a new psychology concept, I prefer to:',
    options: [
      { text: 'Look at diagrams, charts, or visual representations', type: 'V' },
      { text: 'Listen to lectures or audio explanations', type: 'A' },
      { text: 'Read detailed text descriptions', type: 'R' },
      { text: 'Do hands-on activities or role-play scenarios', type: 'K' }
    ]
  },
  {
    id: 2,
    question: 'I remember information best when:',
    options: [
      { text: 'I see it in pictures, videos, or color-coded notes', type: 'V' },
      { text: 'I hear it explained or discuss it with others', type: 'A' },
      { text: 'I write it down or read through my notes', type: 'R' },
      { text: 'I practice applying it or experience it firsthand', type: 'K' }
    ]
  },
  {
    id: 3,
    question: 'When studying for an exam, I usually:',
    options: [
      { text: 'Create mind maps, flowcharts, or highlight with different colors', type: 'V' },
      { text: 'Explain concepts out loud or listen to recorded lectures', type: 'A' },
      { text: 'Read and re-read my textbook and notes', type: 'R' },
      { text: 'Use flashcards, practice problems, or real-world examples', type: 'K' }
    ]
  },
  {
    id: 4,
    question: 'During a psychology lecture, I learn best when the professor:',
    options: [
      { text: 'Uses slides with images, graphs, and diagrams', type: 'V' },
      { text: 'Gives clear verbal explanations and encourages discussion', type: 'A' },
      { text: 'Provides detailed handouts and reading materials', type: 'R' },
      { text: 'Includes demonstrations, case studies, or interactive activities', type: 'K' }
    ]
  },
  {
    id: 5,
    question: 'When I need to understand a complex theory, I prefer to:',
    options: [
      { text: 'Look at visual models or watch explanatory videos', type: 'V' },
      { text: 'Have someone explain it to me verbally', type: 'A' },
      { text: 'Read articles or textbook chapters about it', type: 'R' },
      { text: 'Apply it to real situations or conduct experiments', type: 'K' }
    ]
  },
  {
    id: 6,
    question: 'I find it easier to concentrate when:',
    options: [
      { text: 'The environment is visually organized and uncluttered', type: 'V' },
      { text: 'It\'s quiet or I have background music/sounds', type: 'A' },
      { text: 'I have written materials to follow along with', type: 'R' },
      { text: 'I can move around or fidget while learning', type: 'K' }
    ]
  },
  {
    id: 7,
    question: 'When taking notes in class, I tend to:',
    options: [
      { text: 'Draw diagrams, use symbols, and add visual elements', type: 'V' },
      { text: 'Write down key points from what I hear', type: 'A' },
      { text: 'Write detailed, organized notes in sentences', type: 'R' },
      { text: 'Jot down brief notes and focus on understanding concepts', type: 'K' }
    ]
  },
  {
    id: 8,
    question: 'I best understand research methods when:',
    options: [
      { text: 'I see flowcharts of the research process', type: 'V' },
      { text: 'Someone walks me through it verbally', type: 'A' },
      { text: 'I read step-by-step written instructions', type: 'R' },
      { text: 'I actually conduct a research project myself', type: 'K' }
    ]
  }
];

const learningStyles = {
  V: {
    name: 'Visual Learner',
    icon: Eye,
    color: 'blue',
    description: 'You learn best through visual aids like diagrams, charts, and videos.',
    tips: [
      'Use color-coded notes and highlighters',
      'Create mind maps and flowcharts',
      'Watch educational videos and animations',
      'Draw diagrams to represent concepts',
      'Use visual mnemonics and imagery'
    ]
  },
  A: {
    name: 'Auditory Learner',
    icon: Ear,
    color: 'green',
    description: 'You learn best through listening and verbal communication.',
    tips: [
      'Record and listen to lectures',
      'Participate in study groups and discussions',
      'Read notes aloud to yourself',
      'Use mnemonic rhymes and songs',
      'Explain concepts to others verbally'
    ]
  },
  R: {
    name: 'Reading/Writing Learner',
    icon: BookOpen,
    color: 'purple',
    description: 'You learn best through reading and writing text.',
    tips: [
      'Take detailed written notes',
      'Rewrite notes in your own words',
      'Create lists and outlines',
      'Read textbooks and articles thoroughly',
      'Write summaries and essays'
    ]
  },
  K: {
    name: 'Kinesthetic Learner',
    icon: Hand,
    color: 'orange',
    description: 'You learn best through hands-on experience and practice.',
    tips: [
      'Use real-life examples and case studies',
      'Engage in role-playing activities',
      'Take frequent breaks and move around',
      'Use physical objects or models',
      'Apply concepts through practice and experimentation'
    ]
  }
};

export function VarkAssessment({ onBack }: VarkAssessmentProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<('V' | 'A' | 'R' | 'K')[]>([]);
  const [showResults, setShowResults] = useState(false);

  const handleAnswer = (type: 'V' | 'A' | 'R' | 'K') => {
    const newAnswers = [...answers, type];
    setAnswers(newAnswers);

    if (currentQuestion < varkQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const calculateResults = () => {
    const counts = { V: 0, A: 0, R: 0, K: 0 };
    answers.forEach(answer => {
      counts[answer]++;
    });

    const total = answers.length;
    const percentages = {
      V: Math.round((counts.V / total) * 100),
      A: Math.round((counts.A / total) * 100),
      R: Math.round((counts.R / total) * 100),
      K: Math.round((counts.K / total) * 100)
    };

    const dominant = Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0] as 'V' | 'A' | 'R' | 'K';
    
    return { counts, percentages, dominant };
  };

  const resetAssessment = () => {
    setCurrentQuestion(0);
    setAnswers([]);
    setShowResults(false);
  };

  if (showResults) {
    const { percentages, dominant } = calculateResults();
    const dominantStyle = learningStyles[dominant];
    const DominantIcon = dominantStyle.icon;

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="max-w-4xl mx-auto px-4 py-4">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </button>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full mb-4">
              <DominantIcon className="w-10 h-10 text-white" />
            </div>
            <h1 className="mb-2">Your Learning Style Results</h1>
            <p className="text-gray-600">Based on your responses, here's how you learn best</p>
          </div>

          {/* Dominant Style */}
          <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <div className="flex items-start gap-4 mb-6">
              <div className={`p-3 bg-${dominantStyle.color}-50 rounded-xl`}>
                <DominantIcon className={`w-8 h-8 text-${dominantStyle.color}-600`} />
              </div>
              <div className="flex-1">
                <h2 className="mb-2">Your Primary Style: {dominantStyle.name}</h2>
                <p className="text-gray-700">{dominantStyle.description}</p>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="mb-3">Study Tips for You:</h3>
              <ul className="space-y-2">
                {dominantStyle.tips.map((tip, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* All Styles Breakdown */}
          <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <h3 className="mb-6">Your Learning Style Breakdown</h3>
            <div className="space-y-4">
              {(Object.keys(learningStyles) as Array<'V' | 'A' | 'R' | 'K'>).map((type) => {
                const style = learningStyles[type];
                const Icon = style.icon;
                const percentage = percentages[type];

                return (
                  <div key={type}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Icon className={`w-5 h-5 text-${style.color}-600`} />
                        <span className="text-gray-700">{style.name}</span>
                      </div>
                      <span className="text-gray-600">{percentage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                      <div
                        className={`h-full bg-gradient-to-r from-${style.color}-400 to-${style.color}-600 transition-all duration-500`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex gap-4 justify-center">
            <button
              onClick={resetAssessment}
              className="px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl hover:shadow-lg transition-all"
            >
              Retake Assessment
            </button>
            <button
              onClick={onBack}
              className="px-6 py-3 bg-white border-2 border-gray-200 text-gray-700 rounded-xl hover:border-gray-300 hover:shadow-md transition-all"
            >
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  const progress = ((currentQuestion + 1) / varkQuestions.length) * 100;
  const question = varkQuestions[currentQuestion];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-3xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Exit</span>
            </button>
            <div className="text-sm text-gray-600">
              Question {currentQuestion + 1} of {varkQuestions.length}
            </div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-12">
        <div className="mb-8 text-center">
          <h1 className="mb-2">VARK Learning Styles Assessment</h1>
          <p className="text-gray-600">Discover how you learn best</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 mb-6">
          <h2 className="mb-8 text-gray-800">{question.question}</h2>

          <div className="space-y-3">
            {question.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswer(option.type)}
                className="w-full p-5 rounded-xl border-2 border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-all text-left group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full border-2 border-gray-300 group-hover:border-purple-500 flex items-center justify-center flex-shrink-0">
                    <div className="w-3 h-3 rounded-full bg-transparent group-hover:bg-purple-500 transition-all" />
                  </div>
                  <span className="text-gray-800">{option.text}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="text-center text-sm text-gray-500">
          Select the option that best describes your learning preference
        </div>
      </div>
    </div>
  );
}
