import { Trophy, RotateCcw, Home, CheckCircle, XCircle, BookOpen, Target } from 'lucide-react';

interface ResultsProps {
  results: {
    correct: number;
    total: number;
    answers: boolean[];
  };
  topicName: string;
  subjectName: string;
  onBackToHome: () => void;
  onRetry: () => void;
}

function getLevel(percentage: number) {
  if (percentage >= 90) return { title: 'Advanced', advice: 'Strong mastery. You can revise briefly and move to another topic.' };
  if (percentage >= 70) return { title: 'Developing', advice: 'Good understanding. Review the missed items before moving on.' };
  return { title: 'Foundation', advice: 'Revise the notes first, then retry this quiz slowly.' };
}

export function Results({ results, topicName, subjectName, onBackToHome, onRetry }: ResultsProps) {
  const percentage = Math.round((results.correct / results.total) * 100);
  const isPerfect = percentage === 100;
  const isGood = percentage >= 70;
  const level = getLevel(percentage);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center px-4 py-8">
      <div className="max-w-3xl w-full">
        <div className="bg-white rounded-3xl shadow-2xl p-8 sm:p-10 text-center border-4 border-transparent bg-clip-padding" style={{
          background: 'linear-gradient(white, white) padding-box, linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%) border-box'
        }}>
          <div className={`inline-flex p-7 rounded-full mb-6 ${
            isPerfect ? 'bg-gradient-to-br from-yellow-300 to-orange-400' :
            isGood ? 'bg-gradient-to-br from-green-300 to-emerald-400' :
            'bg-gradient-to-br from-blue-300 to-cyan-400'
          } shadow-xl`}>
            <Trophy className="w-16 h-16 sm:w-20 sm:h-20 text-white drop-shadow-lg" />
          </div>

          <h1 className="mb-3 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            {isPerfect ? 'Perfect Score!' : isGood ? 'Great Job!' : 'Quiz Complete'}
          </h1>
          <p className="text-gray-600 mb-8">{subjectName} • {topicName}</p>

          <div className="mb-8">
            <div className={`text-7xl sm:text-8xl mb-4 bg-gradient-to-r ${
              isPerfect ? 'from-yellow-400 to-orange-500' :
              isGood ? 'from-green-400 to-emerald-500' :
              'from-blue-400 to-cyan-500'
            } bg-clip-text text-transparent drop-shadow-lg`}>
              {percentage}%
            </div>
            <p className="text-gray-600 text-lg">
              You got {results.correct} out of {results.total} questions correct
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8 text-left">
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-5 border border-purple-100">
              <div className="flex items-center gap-3 mb-2">
                <Target className="w-6 h-6 text-purple-600" />
                <h3 className="text-purple-900">Performance Level</h3>
              </div>
              <p className="text-2xl text-purple-700 mb-1">{level.title}</p>
              <p className="text-sm text-gray-600">{level.advice}</p>
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-2xl p-5 border border-blue-100">
              <div className="flex items-center gap-3 mb-2">
                <BookOpen className="w-6 h-6 text-blue-600" />
                <h3 className="text-blue-900">Suggested Next Step</h3>
              </div>
              <p className="text-gray-700">
                {percentage >= 70 ? 'Continue with another topic or try memorizing mode.' : 'Open Notes, revise the topic, then try again.'}
              </p>
            </div>
          </div>

          <div className="mb-8 flex justify-center gap-3 flex-wrap">
            {results.answers.map((correct, index) => (
              <div
                key={index}
                title={`Question ${index + 1}`}
                className={`w-12 h-12 rounded-xl flex items-center justify-center shadow-lg transform hover:scale-110 transition-transform ${
                  correct ? 'bg-gradient-to-br from-green-400 to-emerald-500' : 'bg-gradient-to-br from-red-400 to-pink-500'
                }`}
              >
                {correct ? <CheckCircle className="w-6 h-6 text-white" /> : <XCircle className="w-6 h-6 text-white" />}
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-purple-100 via-pink-100 to-orange-100 rounded-2xl p-6 mb-8 border-2 border-purple-200">
            <p className="text-gray-600 mb-2">XP Earned</p>
            <p className="text-3xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">{results.correct * 10} XP</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={onRetry}
              className="flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-purple-500 via-fuchsia-500 to-pink-500 text-white rounded-2xl hover:shadow-2xl transition-all hover:scale-105 transform"
            >
              <RotateCcw className="w-6 h-6" />
              <span className="text-lg">Try Again</span>
            </button>
            <button
              onClick={onBackToHome}
              className="flex items-center justify-center gap-2 px-8 py-4 bg-white border-2 border-gray-200 text-gray-700 rounded-2xl hover:border-gray-300 hover:shadow-xl transition-all hover:scale-105 transform"
            >
              <Home className="w-6 h-6" />
              <span className="text-lg">Back to Dashboard</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
