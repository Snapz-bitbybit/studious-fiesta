import { Brain, Users, Baby, Lightbulb, Heart, TrendingUp, GraduationCap, Sparkles } from 'lucide-react';
import { Year } from '../App';
import { Header } from './Header';
import { GameCard } from './GameCard';
import { yearsData } from '../data/yearsData';

interface HomeProps {
  onYearSelect: (year: Year) => void;
  onPlayMemoryGame: () => void;
  onOpenNotes: () => void;
  onOpenJournal: () => void;
  onOpenVark: () => void;
}

const yearColors = {
  year1: 'from-cyan-400 via-blue-500 to-indigo-600',
  year2: 'from-green-400 via-emerald-500 to-teal-600',
  year3: 'from-purple-400 via-fuchsia-500 to-pink-600',
  year4: 'from-orange-400 via-red-500 to-pink-600'
};

export function Home({ onYearSelect, onPlayMemoryGame, onOpenNotes, onOpenJournal, onOpenVark }: HomeProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      <Header onOpenNotes={onOpenNotes} onOpenJournal={onOpenJournal} />
      
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* VARK Assessment Banner */}
        <div className="mb-12">
          <button
            onClick={onOpenVark}
            className="w-full bg-gradient-to-r from-yellow-300 via-orange-300 to-pink-300 rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all group transform hover:scale-[1.02]"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6">
                <div className="bg-white p-4 rounded-2xl shadow-lg group-hover:rotate-12 transition-transform">
                  <Sparkles className="w-10 h-10 text-orange-500" />
                </div>
                <div className="text-left">
                  <h3 className="text-white mb-2 drop-shadow-md">Discover Your Learning Style</h3>
                  <p className="text-white/90">
                    Take the VARK assessment to understand how you learn best
                  </p>
                </div>
              </div>
              <div className="bg-white px-8 py-3 rounded-xl group-hover:scale-110 transition-transform shadow-lg">
                <span className="bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">Start VARK</span>
              </div>
            </div>
          </button>
        </div>

        <div className="mb-12 text-center">
          <h2 className="mb-3 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">Select Your Year</h2>
          <p className="text-gray-600">Choose your current academic year to access relevant subjects</p>
        </div>

        {/* Year Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {yearsData.map((year) => (
            <button
              key={year.id}
              onClick={() => onYearSelect(year)}
              className="group bg-white rounded-3xl shadow-lg hover:shadow-2xl transition-all overflow-hidden hover:-translate-y-2 transform"
            >
              <div className={`p-8 bg-gradient-to-br ${yearColors[year.id as keyof typeof yearColors]} text-white relative overflow-hidden`}>
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
                <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
                <div className="relative z-10">
                  <GraduationCap className="w-14 h-14 mb-4 drop-shadow-lg" />
                  <h3 className="text-white mb-2 drop-shadow-md">{year.name}</h3>
                  <p className="text-sm text-white/90">{year.subjects.length} subjects</p>
                </div>
              </div>
              <div className="p-5 bg-gradient-to-br from-gray-50 to-white">
                <div className="text-sm text-gray-600 space-y-1">
                  {year.subjects.slice(0, 2).map((subject, idx) => (
                    <div key={idx} className="truncate flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-gradient-to-r from-purple-400 to-pink-400"></div>
                      {subject.name}
                    </div>
                  ))}
                  {year.subjects.length > 2 && (
                    <div className="text-purple-500">+ {year.subjects.length - 2} more</div>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Games Section */}
        <div className="mt-20">
          <div className="mb-8 text-center">
            <h2 className="mb-3 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 bg-clip-text text-transparent">Take a Break with Games</h2>
            <p className="text-gray-600">Fun games to reinforce learning</p>
          </div>
          
          <div className="max-w-md mx-auto">
            <GameCard onPlayMemoryGame={onPlayMemoryGame} />
          </div>
        </div>
      </main>
    </div>
  );
}