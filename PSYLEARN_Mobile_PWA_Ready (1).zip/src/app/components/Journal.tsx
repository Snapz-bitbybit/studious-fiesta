import { useState } from 'react';
import { ArrowLeft, Plus, Trash2, FileText, Calendar, Smile, Meh, Frown } from 'lucide-react';

interface JournalEntry {
  id: string;
  title: string;
  content: string;
  mood: 'happy' | 'neutral' | 'sad';
  createdAt: Date;
}

interface JournalProps {
  onBack: () => void;
}

const initialEntries: JournalEntry[] = [
  {
    id: '1',
    title: 'Great study session today',
    content: 'Completed all quizzes on Cognitive Psychology. Finally understanding the difference between short-term and long-term memory. The explanations really helped!',
    mood: 'happy',
    createdAt: new Date('2024-01-15')
  },
  {
    id: '2',
    title: 'Finding Social Psychology challenging',
    content: 'The concepts of conformity and obedience are fascinating but complex. Need to review Asch and Milgram experiments more thoroughly.',
    mood: 'neutral',
    createdAt: new Date('2024-01-14')
  }
];

const moodIcons = {
  happy: { icon: Smile, color: 'text-green-500', bg: 'bg-green-50' },
  neutral: { icon: Meh, color: 'text-yellow-500', bg: 'bg-yellow-50' },
  sad: { icon: Frown, color: 'text-red-500', bg: 'bg-red-50' }
};

export function Journal({ onBack }: JournalProps) {
  const [entries, setEntries] = useState<JournalEntry[]>(initialEntries);
  const [isCreating, setIsCreating] = useState(false);
  const [newEntry, setNewEntry] = useState({
    title: '',
    content: '',
    mood: 'neutral' as 'happy' | 'neutral' | 'sad'
  });

  const handleCreateEntry = () => {
    if (!newEntry.title.trim() || !newEntry.content.trim()) return;

    const entry: JournalEntry = {
      id: Date.now().toString(),
      title: newEntry.title,
      content: newEntry.content,
      mood: newEntry.mood,
      createdAt: new Date()
    };

    setEntries([entry, ...entries]);
    setNewEntry({ title: '', content: '', mood: 'neutral' });
    setIsCreating(false);
  };

  const handleDeleteEntry = (id: string) => {
    setEntries(entries.filter(entry => entry.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </button>
            <div className="flex items-center gap-3">
              <FileText className="w-6 h-6 text-purple-600" />
              <h1 className="text-purple-600">Study Journal</h1>
            </div>
            <button
              onClick={() => setIsCreating(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-lg hover:shadow-lg transition-all"
            >
              <Plus className="w-5 h-5" />
              <span>New Entry</span>
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8 text-center">
          <p className="text-gray-600">
            Reflect on your learning journey, track your progress, and note your thoughts
          </p>
        </div>

        {/* Create Entry Modal */}
        {isCreating && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <h2 className="mb-4">New Journal Entry</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-600 mb-2">How are you feeling?</label>
                  <div className="flex gap-3">
                    {(Object.keys(moodIcons) as Array<'happy' | 'neutral' | 'sad'>).map((mood) => {
                      const MoodIcon = moodIcons[mood].icon;
                      return (
                        <button
                          key={mood}
                          onClick={() => setNewEntry({ ...newEntry, mood })}
                          className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border-2 transition-all ${
                            newEntry.mood === mood
                              ? `${moodIcons[mood].bg} border-${mood === 'happy' ? 'green' : mood === 'neutral' ? 'yellow' : 'red'}-300`
                              : 'border-gray-200 hover:bg-gray-50'
                          }`}
                        >
                          <MoodIcon className={`w-6 h-6 ${newEntry.mood === mood ? moodIcons[mood].color : 'text-gray-400'}`} />
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-2">Title</label>
                  <input
                    type="text"
                    value={newEntry.title}
                    onChange={(e) => setNewEntry({ ...newEntry, title: e.target.value })}
                    placeholder="Today's learning highlights..."
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 mb-2">Your Thoughts</label>
                  <textarea
                    value={newEntry.content}
                    onChange={(e) => setNewEntry({ ...newEntry, content: e.target.value })}
                    placeholder="What did you learn today? What challenges did you face? What are you proud of?"
                    rows={10}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={handleCreateEntry}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white rounded-xl hover:shadow-lg transition-all"
                >
                  Save Entry
                </button>
                <button
                  onClick={() => {
                    setIsCreating(false);
                    setNewEntry({ title: '', content: '', mood: 'neutral' });
                  }}
                  className="px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-all"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Journal Entries */}
        {entries.length === 0 ? (
          <div className="text-center py-16">
            <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No journal entries yet. Start documenting your learning journey!</p>
          </div>
        ) : (
          <div className="space-y-6">
            {entries.map((entry) => {
              const MoodIcon = moodIcons[entry.mood].icon;
              return (
                <div
                  key={entry.id}
                  className="bg-white rounded-2xl p-6 shadow-md hover:shadow-lg transition-all"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3 flex-1">
                      <div className={`p-2 rounded-lg ${moodIcons[entry.mood].bg}`}>
                        <MoodIcon className={`w-6 h-6 ${moodIcons[entry.mood].color}`} />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-gray-800">{entry.title}</h3>
                        <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                          <Calendar className="w-4 h-4" />
                          <span>{entry.createdAt.toLocaleDateString('en-US', { 
                            weekday: 'long', 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                          })}</span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteEntry(entry.id)}
                      className="text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                  
                  <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                    {entry.content}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
