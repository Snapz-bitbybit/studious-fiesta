import { BookOpen, Users, Gamepad2, Award, ArrowRight } from 'lucide-react';
import logo from "figma:asset/daabe322baca76a4bfd50f56360517223f21f9cf.png";

interface LandingScreenProps {
  onEnter: () => void;
}

export function LandingScreen({ onEnter }: LandingScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center px-4 py-12 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
        <div className="absolute bottom-20 left-1/2 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-4000"></div>
      </div>

      <div className="max-w-5xl w-full relative z-10">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-3 mb-6 animate-bounce">
            <div className="bg-white rounded-3xl shadow-2xl transform rotate-6 hover:rotate-12 transition-transform overflow-hidden w-28 h-28">
              <img src={logo} alt="PSYLEARN Logo" className="w-full h-full object-cover" />
            </div>
          </div>
          <h1 className="text-7xl text-white mb-4 drop-shadow-lg">PSYLEARN</h1>
          <p className="text-3xl text-white/90 mb-8 font-light">
            Master Psychology Through Interactive Learning
          </p>
          <button
            onClick={onEnter}
            className="group inline-flex items-center gap-3 px-10 py-5 bg-gradient-to-r from-yellow-400 via-orange-400 to-pink-500 text-white rounded-2xl hover:shadow-2xl transition-all hover:scale-110 transform"
          >
            <span className="text-2xl">Start Learning</span>
            <ArrowRight className="w-7 h-7 group-hover:translate-x-2 transition-transform" />
          </button>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white/15 backdrop-blur-xl rounded-3xl p-6 border border-white/30 hover:bg-white/25 transition-all hover:scale-105 transform">
            <div className="bg-gradient-to-br from-blue-400 to-cyan-400 p-4 rounded-2xl w-fit mb-4 shadow-lg">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-white mb-2">Interactive Quizzes</h3>
            <p className="text-sm text-white/80">
              Test your knowledge with engaging multiple-choice questions
            </p>
          </div>

          <div className="bg-white/15 backdrop-blur-xl rounded-3xl p-6 border border-white/30 hover:bg-white/25 transition-all hover:scale-105 transform">
            <div className="bg-gradient-to-br from-purple-400 to-fuchsia-400 p-4 rounded-2xl w-fit mb-4 shadow-lg">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-white mb-2">6 Psychology Subjects</h3>
            <p className="text-sm text-white/80">
              From cognitive to clinical psychology, we've got you covered
            </p>
          </div>

          <div className="bg-white/15 backdrop-blur-xl rounded-3xl p-6 border border-white/30 hover:bg-white/25 transition-all hover:scale-105 transform">
            <div className="bg-gradient-to-br from-pink-400 to-rose-400 p-4 rounded-2xl w-fit mb-4 shadow-lg">
              <Gamepad2 className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-white mb-2">Fun Games</h3>
            <p className="text-sm text-white/80">
              Memory games and challenges to make learning enjoyable
            </p>
          </div>

          <div className="bg-white/15 backdrop-blur-xl rounded-3xl p-6 border border-white/30 hover:bg-white/25 transition-all hover:scale-105 transform">
            <div className="bg-gradient-to-br from-yellow-400 to-orange-400 p-4 rounded-2xl w-fit mb-4 shadow-lg">
              <Award className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-white mb-2">Track Progress</h3>
            <p className="text-sm text-white/80">
              Earn XP, maintain streaks, and monitor your improvement
            </p>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-12 flex justify-center gap-16">
          <div className="text-center">
            <div className="text-5xl text-yellow-300 mb-2 drop-shadow-lg">6</div>
            <div className="text-white/90">Subjects</div>
          </div>
          <div className="text-center">
            <div className="text-5xl text-yellow-300 mb-2 drop-shadow-lg">100+</div>
            <div className="text-white/90">Questions</div>
          </div>
          <div className="text-center">
            <div className="text-5xl text-yellow-300 mb-2 drop-shadow-lg">3</div>
            <div className="text-white/90">Study Modes</div>
          </div>
        </div>
      </div>
    </div>
  );
}