import { Grid3x3, Sparkles } from 'lucide-react';

interface GameCardProps {
  onPlayMemoryGame: () => void;
}

export function GameCard({ onPlayMemoryGame }: GameCardProps) {
  return (
    <button
      onClick={onPlayMemoryGame}
      className="w-full bg-gradient-to-br from-pink-100 via-purple-100 to-indigo-100 rounded-3xl shadow-xl hover:shadow-2xl transition-all p-8 group hover:-translate-y-2 transform border-2 border-white"
    >
      <div className="flex items-center gap-6">
        <div className="relative">
          <div className="bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-500 p-5 rounded-2xl group-hover:scale-110 transition-transform shadow-lg">
            <Grid3x3 className="w-10 h-10 text-white" />
          </div>
          <Sparkles className="absolute -top-2 -right-2 w-7 h-7 text-yellow-400 animate-pulse" />
        </div>
        
        <div className="flex-1 text-left">
          <h3 className="bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-1">Memory Card Game</h3>
          <p className="text-sm text-gray-600">
            Match emoji pairs and sharpen your memory skills
          </p>
        </div>
        
        <div className="bg-gradient-to-r from-pink-500 to-purple-500 px-6 py-3 rounded-xl shadow-lg group-hover:scale-110 transition-transform">
          <span className="text-white">Play</span>
        </div>
      </div>
    </button>
  );
}