import { LucideIcon, ChevronRight } from 'lucide-react';
import { Subject, Topic } from '../App';
import { useState } from 'react';

interface SubjectCardProps {
  subject: Subject;
  icon: LucideIcon;
  onStartQuiz: (subject: Subject, topic: Topic) => void;
}

const colorClasses = {
  purple: 'from-purple-400 via-fuchsia-400 to-pink-500 hover:from-purple-500 hover:via-fuchsia-500 hover:to-pink-600',
  blue: 'from-blue-400 via-cyan-400 to-teal-500 hover:from-blue-500 hover:via-cyan-500 hover:to-teal-600',
  green: 'from-green-400 via-emerald-400 to-teal-500 hover:from-green-500 hover:via-emerald-500 hover:to-teal-600',
  red: 'from-red-400 via-pink-400 to-rose-500 hover:from-red-500 hover:via-pink-500 hover:to-rose-600',
  orange: 'from-orange-400 via-amber-400 to-yellow-500 hover:from-orange-500 hover:via-amber-500 hover:to-yellow-600',
  indigo: 'from-indigo-400 via-purple-400 to-fuchsia-500 hover:from-indigo-500 hover:via-purple-500 hover:to-fuchsia-600',
  pink: 'from-pink-400 via-rose-400 to-red-500 hover:from-pink-500 hover:via-rose-500 hover:to-red-600'
};

const lightColorClasses = {
  purple: 'bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200 hover:border-purple-300',
  blue: 'bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200 hover:border-blue-300',
  green: 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 hover:border-green-300',
  red: 'bg-gradient-to-br from-red-50 to-pink-50 border-red-200 hover:border-red-300',
  orange: 'bg-gradient-to-br from-orange-50 to-yellow-50 border-orange-200 hover:border-orange-300',
  indigo: 'bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-200 hover:border-indigo-300',
  pink: 'bg-gradient-to-br from-pink-50 to-rose-50 border-pink-200 hover:border-pink-300'
};

export function SubjectCard({ subject, icon: Icon, onStartQuiz }: SubjectCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-white rounded-3xl shadow-lg hover:shadow-2xl transition-all overflow-hidden border-2 border-gray-100 hover:border-gray-200">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className={`w-full p-8 bg-gradient-to-br ${colorClasses[subject.color as keyof typeof colorClasses]} text-white transition-all relative overflow-hidden`}
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/10 rounded-full -ml-12 -mb-12"></div>
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-white/25 backdrop-blur-sm p-4 rounded-2xl shadow-lg">
              <Icon className="w-10 h-10" />
            </div>
            <div className="text-left">
              <h3 className="text-white drop-shadow-md">{subject.name}</h3>
              <p className="text-sm text-white/90">{subject.topics.length} topics</p>
            </div>
          </div>
          <ChevronRight className={`w-7 h-7 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
        </div>
      </button>

      {isExpanded && (
        <div className="p-5 space-y-3 bg-gradient-to-br from-gray-50 to-white">
          {subject.topics.map((topic) => (
            <button
              key={topic.id}
              onClick={() => onStartQuiz(subject, topic)}
              className={`w-full p-5 rounded-2xl border-2 ${lightColorClasses[subject.color as keyof typeof lightColorClasses]} hover:shadow-lg transition-all text-left group`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-gray-800 mb-1">{topic.name}</h4>
                  <p className="text-sm text-gray-500">{topic.questions.length} questions</p>
                </div>
                <div className="bg-white p-3 rounded-xl group-hover:translate-x-1 transition-transform shadow-md">
                  <ChevronRight className="w-5 h-5 text-gray-600" />
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}