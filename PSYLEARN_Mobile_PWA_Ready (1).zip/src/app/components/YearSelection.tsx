import { ArrowLeft, Brain, Users, Baby, Lightbulb, Heart, TrendingUp, Briefcase, Beaker, Activity, GraduationCap } from 'lucide-react';
import { Year, Subject, Topic } from '../App';
import { SubjectCard } from './SubjectCard';

interface YearSelectionProps {
  year: Year;
  onStartQuiz: (subject: Subject, topic: Topic) => void;
  onBack: () => void;
}

const iconMap = {
  brain: Brain,
  users: Users,
  baby: Baby,
  lightbulb: Lightbulb,
  heart: Heart,
  'trending-up': TrendingUp,
  briefcase: Briefcase,
  flask: Beaker,
  activity: Activity
};

const yearColors = {
  year1: 'from-blue-500 to-blue-600',
  year2: 'from-green-500 to-green-600',
  year3: 'from-purple-500 to-purple-600',
  year4: 'from-orange-500 to-orange-600'
};

export function YearSelection({ year, onStartQuiz, onBack }: YearSelectionProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Years</span>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Year Header */}
        <div className="mb-12 text-center">
          <div className={`inline-flex items-center gap-3 px-6 py-3 bg-gradient-to-r ${yearColors[year.id as keyof typeof yearColors]} text-white rounded-2xl mb-4 shadow-lg`}>
            <GraduationCap className="w-8 h-8" />
            <h1 className="text-white">{year.name}</h1>
          </div>
          <p className="text-gray-600 mt-4">
            Select a subject to begin your learning journey
          </p>
        </div>

        {/* Subjects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {year.subjects.map((subject) => {
            const Icon = iconMap[subject.icon as keyof typeof iconMap] || Brain;
            return (
              <SubjectCard
                key={subject.id}
                subject={subject}
                icon={Icon}
                onStartQuiz={onStartQuiz}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}