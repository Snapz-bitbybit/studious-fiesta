import { ArrowLeft, BookOpen, Brain, Users } from 'lucide-react';
import { Subject, Topic, QuizMode } from '../App';

interface ModeSelectionProps {
  subject: Subject;
  topic: Topic;
  onModeSelect: (mode: QuizMode) => void;
  onBack: () => void;
}

const colorClasses = {
  purple: 'from-purple-500 to-purple-600',
  blue: 'from-blue-500 to-blue-600',
  green: 'from-green-500 to-green-600',
  red: 'from-red-500 to-red-600',
  orange: 'from-orange-500 to-orange-600',
  indigo: 'from-indigo-500 to-indigo-600'
};

export function ModeSelection({ subject, topic, onModeSelect, onBack }: ModeSelectionProps) {
  const modes = [
    {
      id: 'understanding' as QuizMode,
      icon: BookOpen,
      title: 'Understanding Mode',
      description: 'Learn concepts with detailed explanations after each question',
      color: 'from-blue-500 to-blue-600',
      features: ['Detailed explanations', 'No time pressure', 'Perfect for learning']
    },
    {
      id: 'memorizing' as QuizMode,
      icon: Brain,
      title: 'Memorizing Mode',
      description: 'Quick-fire questions to test your memory and recall',
      color: 'from-purple-500 to-purple-600',
      features: ['Timed questions', 'Instant feedback', 'Build muscle memory']
    },
    {
      id: 'challenge' as QuizMode,
      icon: Users,
      title: 'Challenge with Friends',
      description: 'Compete with friends and see who scores higher',
      color: 'from-green-500 to-green-600',
      features: ['Competitive mode', 'Share results', 'Leaderboard ready'],
      comingSoon: true
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className={`inline-block px-4 py-2 bg-gradient-to-r ${colorClasses[subject.color as keyof typeof colorClasses]} text-white rounded-full mb-4`}>
            {subject.name}
          </div>
          <h1 className="mb-3">{topic.name}</h1>
          <p className="text-gray-600">Choose how you want to study</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {modes.map((mode) => {
            const Icon = mode.icon;
            return (
              <button
                key={mode.id}
                onClick={() => !mode.comingSoon && onModeSelect(mode.id)}
                disabled={mode.comingSoon}
                className={`relative bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all p-6 text-left ${
                  mode.comingSoon ? 'opacity-60 cursor-not-allowed' : 'hover:-translate-y-1'
                }`}
              >
                {mode.comingSoon && (
                  <div className="absolute top-4 right-4 bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-xs">
                    Coming Soon
                  </div>
                )}

                <div className={`inline-flex p-4 bg-gradient-to-br ${mode.color} rounded-xl mb-4`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>

                <h3 className="mb-2 text-gray-800">{mode.title}</h3>
                <p className="text-sm text-gray-600 mb-4">{mode.description}</p>

                <div className="space-y-2">
                  {mode.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm text-gray-500">
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
