import { useEffect, useMemo, useState } from 'react';
import { Topic, QuizMode } from '../App';
import { ArrowLeft, CheckCircle, XCircle, Clock, Lightbulb, Zap } from 'lucide-react';

interface QuizProps {
  topic: Topic;
  subjectName: string;
  subjectColor: string;
  mode: QuizMode;
  onComplete: (correct: number, total: number, answers: boolean[]) => void;
  onBack: () => void;
}

const colorClasses = {
  purple: 'bg-gradient-to-r from-purple-500 via-fuchsia-500 to-pink-500',
  blue: 'bg-gradient-to-r from-blue-500 via-cyan-500 to-teal-500',
  green: 'bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500',
  red: 'bg-gradient-to-r from-red-500 via-pink-500 to-rose-500',
  orange: 'bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500',
  indigo: 'bg-gradient-to-r from-indigo-500 via-purple-500 to-fuchsia-500',
  pink: 'bg-gradient-to-r from-pink-500 via-rose-500 to-red-500'
};

const modeLabel: Record<QuizMode, string> = {
  understanding: 'Understanding Mode',
  memorizing: 'Memorizing Mode',
  challenge: 'Challenge Mode'
};

export function Quiz({ topic, subjectName, subjectColor, mode, onComplete, onBack }: QuizProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [answers, setAnswers] = useState<boolean[]>([]);
  const [timer, setTimer] = useState(30);

  const currentQuestion = topic.questions[currentQuestionIndex];
  const totalQuestions = topic.questions.length;
  const progress = ((currentQuestionIndex + 1) / totalQuestions) * 100;
  const isMemorizingMode = mode === 'memorizing';
  const isCorrect = selectedAnswer === currentQuestion.correctAnswer;
  const currentScore = answers.filter(Boolean).length;

  const learningTip = useMemo(() => {
    if (!showExplanation) return 'Read the question carefully, then choose the strongest answer.';
    if (isCorrect) return 'Good. Keep linking the answer with the concept, not just the keyword.';
    return 'Review why the correct answer fits better. This is where learning actually happens.';
  }, [showExplanation, isCorrect]);

  useEffect(() => {
    if (!isMemorizingMode || showExplanation) return;

    const interval = window.setInterval(() => {
      setTimer((prev) => {
        if (prev <= 1) {
          setShowExplanation(true);
          setAnswers((prevAnswers) => [...prevAnswers, false]);
          return 30;
        }
        return prev - 1;
      });
    }, 1000);

    return () => window.clearInterval(interval);
  }, [isMemorizingMode, showExplanation, currentQuestionIndex]);

  const recordAnswer = (answerIndex: number | null) => {
    const correct = answerIndex === currentQuestion.correctAnswer;
    setAnswers((prev) => [...prev, correct]);
  };

  const handleAnswerSelect = (index: number) => {
    if (showExplanation) return;
    setSelectedAnswer(index);

    if (isMemorizingMode) {
      window.setTimeout(() => {
        setShowExplanation(true);
        recordAnswer(index);
      }, 250);
    }
  };

  const handleCheckAnswer = () => {
    if (selectedAnswer === null || showExplanation) return;
    setShowExplanation(true);
    recordAnswer(selectedAnswer);
  };

  const handleNext = () => {
    if (currentQuestionIndex < totalQuestions - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
      setTimer(30);
      return;
    }

    onComplete(answers.filter(Boolean).length, totalQuestions, answers);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-50">
      <div className="bg-white/90 backdrop-blur shadow-sm border-b border-indigo-100 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Exit Quiz</span>
            </button>

            <div className="flex items-center gap-3 text-sm">
              <div className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-full bg-purple-50 text-purple-700 border border-purple-100">
                <Zap className="w-4 h-4" />
                <span>{currentScore}/{answers.length || 0} correct</span>
              </div>
              {isMemorizingMode && !showExplanation && (
                <div className="flex items-center gap-2 px-3 py-2 rounded-full bg-orange-50 text-orange-700 border border-orange-100">
                  <Clock className="w-4 h-4" />
                  <span className="font-mono">{timer}s</span>
                </div>
              )}
              <div className="px-3 py-2 rounded-full bg-gray-50 text-gray-700 border border-gray-100">
                Question {currentQuestionIndex + 1} / {totalQuestions}
              </div>
            </div>
          </div>

          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <div
              className={`h-full ${colorClasses[subjectColor as keyof typeof colorClasses] || colorClasses.purple} transition-all duration-500`}
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="max-w-3xl w-full">
          <div className="mb-5 text-center">
            <span className="inline-block px-5 py-2 bg-white rounded-full text-sm text-purple-700 border border-purple-200 shadow-sm">
              {subjectName} • {topic.name} • {modeLabel[mode]}
            </span>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-7 sm:p-10 mb-6 border border-indigo-100">
            <div className="flex items-start gap-3 mb-7">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 text-white flex items-center justify-center shrink-0 shadow-md">
                {currentQuestionIndex + 1}
              </div>
              <h2 className="text-gray-900 leading-snug">{currentQuestion.question}</h2>
            </div>

            <div className="space-y-4">
              {currentQuestion.options.map((option, index) => {
                let buttonClass = 'w-full p-5 rounded-2xl border-2 text-left transition-all transform ';

                if (showExplanation) {
                  if (index === currentQuestion.correctAnswer) {
                    buttonClass += 'border-green-400 bg-gradient-to-r from-green-50 to-emerald-50 shadow-md';
                  } else if (index === selectedAnswer) {
                    buttonClass += 'border-red-400 bg-gradient-to-r from-red-50 to-pink-50 shadow-md';
                  } else {
                    buttonClass += 'border-gray-200 bg-gray-50 opacity-75';
                  }
                } else if (index === selectedAnswer) {
                  buttonClass += 'border-purple-400 bg-gradient-to-r from-purple-50 to-pink-50 shadow-lg scale-[1.01]';
                } else {
                  buttonClass += 'border-gray-200 hover:border-purple-300 hover:bg-gradient-to-r hover:from-purple-50 hover:to-pink-50 hover:shadow-md hover:scale-[1.01]';
                }

                return (
                  <button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    className={buttonClass}
                    disabled={showExplanation}
                  >
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-gray-800">{option}</span>
                      {showExplanation && index === currentQuestion.correctAnswer && (
                        <CheckCircle className="w-6 h-6 text-green-500 shrink-0" />
                      )}
                      {showExplanation && index === selectedAnswer && index !== currentQuestion.correctAnswer && (
                        <XCircle className="w-6 h-6 text-red-500 shrink-0" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {showExplanation && (
            <div className={`rounded-3xl p-7 mb-6 border-2 ${isCorrect ? 'bg-gradient-to-r from-green-50 to-emerald-50 border-green-300' : 'bg-gradient-to-r from-red-50 to-pink-50 border-red-300'} shadow-xl`}>
              <div className="flex items-start gap-4">
                {isCorrect ? (
                  <CheckCircle className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
                ) : (
                  <XCircle className="w-8 h-8 text-red-600 flex-shrink-0 mt-1" />
                )}
                <div>
                  <h4 className={isCorrect ? 'text-green-800 text-xl' : 'text-red-800 text-xl'}>
                    {isCorrect ? 'Correct!' : 'Not quite'}
                  </h4>
                  <p className="text-gray-700 mt-2 text-lg">{currentQuestion.explanation}</p>
                </div>
              </div>
            </div>
          )}

          <div className="bg-white/80 border border-indigo-100 rounded-2xl p-4 mb-6 flex gap-3 items-start shadow-sm">
            <Lightbulb className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
            <p className="text-sm text-gray-600">{learningTip}</p>
          </div>

          <div className="flex justify-center">
            {!showExplanation && !isMemorizingMode ? (
              <button
                onClick={handleCheckAnswer}
                disabled={selectedAnswer === null}
                className={`px-10 py-4 rounded-2xl text-white text-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-xl ${
                  selectedAnswer !== null
                    ? `${colorClasses[subjectColor as keyof typeof colorClasses] || colorClasses.purple} hover:shadow-2xl hover:scale-105 transform`
                    : 'bg-gray-300'
                }`}
              >
                Check Answer
              </button>
            ) : showExplanation ? (
              <button
                onClick={handleNext}
                className={`px-10 py-4 rounded-2xl ${colorClasses[subjectColor as keyof typeof colorClasses] || colorClasses.purple} text-white text-lg hover:shadow-2xl transition-all hover:scale-105 transform shadow-xl`}
              >
                {currentQuestionIndex < totalQuestions - 1 ? 'Next Question' : 'See Results'}
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
