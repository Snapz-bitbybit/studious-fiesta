import { useState, useEffect } from 'react';
import { ArrowLeft, RotateCcw, Trophy, Clock } from 'lucide-react';

interface Card {
  id: number;
  term: string;
  isFlipped: boolean;
  isMatched: boolean;
}

interface MemoryGameProps {
  onBack: () => void;
}

const psychologyTerms = [
  { term: '🐶', pair: '🐕' },
  { term: '🌟', pair: '⭐' },
  { term: '🍎', pair: '🍏' },
  { term: '🚗', pair: '🚙' },
  { term: '🌸', pair: '🌺' },
  { term: '🎵', pair: '🎶' },
  { term: '🌙', pair: '🌛' },
  { term: '💙', pair: '💜' }
];

export function MemoryGame({ onBack }: MemoryGameProps) {
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [matches, setMatches] = useState(0);
  const [isComplete, setIsComplete] = useState(false);
  const [timer, setTimer] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  useEffect(() => {
    initializeGame();
  }, []);

  useEffect(() => {
    if (isTimerRunning) {
      const interval = setInterval(() => {
        setTimer((prev) => prev + 1);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isTimerRunning]);

  const initializeGame = () => {
    const gameCards: Card[] = [];
    let id = 0;

    psychologyTerms.forEach((pair) => {
      gameCards.push({
        id: id++,
        term: pair.term,
        isFlipped: false,
        isMatched: false
      });
      gameCards.push({
        id: id++,
        term: pair.pair,
        isFlipped: false,
        isMatched: false
      });
    });

    // Shuffle cards
    const shuffled = gameCards.sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setFlippedCards([]);
    setMoves(0);
    setMatches(0);
    setIsComplete(false);
    setTimer(0);
    setIsTimerRunning(false);
  };

  const handleCardClick = (index: number) => {
    if (!isTimerRunning) {
      setIsTimerRunning(true);
    }

    if (
      flippedCards.length === 2 ||
      cards[index].isFlipped ||
      cards[index].isMatched
    ) {
      return;
    }

    const newCards = [...cards];
    newCards[index].isFlipped = true;
    setCards(newCards);

    const newFlippedCards = [...flippedCards, index];
    setFlippedCards(newFlippedCards);

    if (newFlippedCards.length === 2) {
      setMoves(moves + 1);
      checkMatch(newFlippedCards);
    }
  };

  const checkMatch = (flippedIndices: number[]) => {
    const [first, second] = flippedIndices;
    const firstCard = cards[first];
    const secondCard = cards[second];

    // Find if these cards form a matching pair
    const isMatch = psychologyTerms.some(
      (pair) =>
        (pair.term === firstCard.term && pair.pair === secondCard.term) ||
        (pair.pair === firstCard.term && pair.term === secondCard.term)
    );

    setTimeout(() => {
      const newCards = [...cards];
      if (isMatch) {
        newCards[first].isMatched = true;
        newCards[second].isMatched = true;
        setMatches(matches + 1);

        // Check if game is complete
        if (matches + 1 === psychologyTerms.length) {
          setIsComplete(true);
          setIsTimerRunning(false);
        }
      } else {
        newCards[first].isFlipped = false;
        newCards[second].isFlipped = false;
      }
      setCards(newCards);
      setFlippedCards([]);
    }, 1000);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Home</span>
            </button>

            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-500" />
                <span className="text-gray-700 font-mono">{formatTime(timer)}</span>
              </div>
              <div className="text-gray-700">
                Moves: <span>{moves}</span>
              </div>
              <div className="text-gray-700">
                Matches: <span className="text-green-600">{matches}/{psychologyTerms.length}</span>
              </div>
              <button
                onClick={initializeGame}
                className="flex items-center gap-2 px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>New Game</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Game Content */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="mb-8 text-center">
          <h1 className="mb-2">Memory Card Game</h1>
          <p className="text-gray-600">Match the similar emoji pairs</p>
        </div>

        {isComplete && (
          <div className="max-w-md mx-auto mb-8 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-2xl p-6 text-center">
            <Trophy className="w-12 h-12 text-yellow-500 mx-auto mb-3" />
            <h2 className="mb-2 text-green-800">Congratulations!</h2>
            <p className="text-gray-700 mb-2">
              You completed the game in <span className="text-green-600">{formatTime(timer)}</span> with <span className="text-green-600">{moves}</span> moves
            </p>
            <p className="text-sm text-gray-600">+50 XP Earned!</p>
          </div>
        )}

        <div className="grid grid-cols-4 gap-4 max-w-4xl mx-auto">
          {cards.map((card, index) => (
            <button
              key={card.id}
              onClick={() => handleCardClick(index)}
              disabled={card.isMatched || card.isFlipped}
              className={`aspect-square rounded-xl transition-all duration-300 transform ${
                card.isFlipped || card.isMatched
                  ? 'bg-white shadow-lg'
                  : 'bg-gradient-to-br from-purple-500 to-blue-500 hover:scale-105'
              } ${
                card.isMatched
                  ? 'opacity-50 cursor-default'
                  : 'cursor-pointer'
              }`}
            >
              <div className="h-full flex items-center justify-center p-3">
                {card.isFlipped || card.isMatched ? (
                  <span className="text-center text-4xl">
                    {card.term}
                  </span>
                ) : (
                  <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-lg" />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}